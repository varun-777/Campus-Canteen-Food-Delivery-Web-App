document.addEventListener('DOMContentLoaded', () => {
    // Sync the theme icon
    const savedTheme = localStorage.getItem('sa_theme') || 'light';
    const themeBtn = document.getElementById('themeToggle');
    if (themeBtn) {
        themeBtn.textContent = savedTheme === 'dark' ? '☀️' : '🌙';
    }

    if (localStorage.getItem('super_admin_session') !== 'active') {
        window.location.href = 'super-admin-login.html';
        return;
    }

    loadData();

    // Image Preview Handling
    window.previewImage = function(event) {
        const reader = new FileReader();
        reader.onload = function() {
            const output = document.getElementById('imagePreview');
            const placeholder = document.getElementById('previewPlaceholder');
            output.src = reader.result;
            output.style.display = 'block';
            placeholder.style.display = 'none';
        };
        reader.readAsDataURL(event.target.files[0]);
    };

    // Form Handling
    const addForm = document.getElementById('addCanteenForm');
    addForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const name = document.getElementById('canteenName').value;
        const location = document.getElementById('canteenLocation').value;
        const category = document.getElementById('canteenCategory').value;
        const imageInput = document.getElementById('canteenImageInput');
        const errorMsg = document.getElementById('modalErrorMsg');
        const successMsg = document.getElementById('successMsg');

        let imageBase64 = null;
        if (imageInput.files && imageInput.files[0]) {
            const reader = new FileReader();
            imageBase64 = await new Promise((resolve) => {
                reader.onload = () => resolve(reader.result);
                reader.readAsDataURL(imageInput.files[0]);
            });
        }

        try {
            const res = await fetch('/api/superadmin/add-canteen', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name, location, category, image: imageBase64 })
            });

            const data = await res.json();
            if (res.ok) {
                successMsg.textContent = `Canteen added! Email: ${data.canteen.email} | Pass: ${data.canteen.password}`;
                successMsg.style.display = 'block';
                errorMsg.style.display = 'none';
                addForm.reset();
                document.getElementById('imagePreview').style.display = 'none';
                document.getElementById('previewPlaceholder').style.display = 'block';
                loadData();
            } else {
                errorMsg.textContent = data.message || 'Failed to add canteen';
                errorMsg.style.display = 'block';
                successMsg.style.display = 'none';
            }
        } catch (err) {
            errorMsg.textContent = 'Server connection error';
            errorMsg.style.display = 'block';
        }
    });
});

let globalCanteensList = [];

async function loadData() {
    try {
        // Fetch Stats
        const statsRes = await fetch('/api/superadmin/stats');
        const stats = await statsRes.json();
        document.getElementById('statTotalCanteens').textContent = stats.totalCanteens || 0;
        document.getElementById('statTotalOrders').textContent = stats.totalOrders || 0;
        document.getElementById('statTotalFood').textContent = stats.totalFood || 0;

        // Fetch Canteens
        const canteensRes = await fetch('/api/superadmin/canteens');
        globalCanteensList = await canteensRes.json();
        
        // Render based on active filter
        const activeBtn = document.querySelector('.filter-btn.active');
        if (activeBtn) {
            activeBtn.click(); // Re-trigger filter
        } else {
            renderCanteensTable(globalCanteensList);
        }
    } catch (err) {
        console.error('Error loading dashboard data:', err);
    }
}

function renderCanteensTable(canteens) {
    const tableBody = document.getElementById('canteenTableBody');
    tableBody.innerHTML = '';

    canteens.forEach(c => {
        let catDisplay = 'General';
        if (c.category === 'hostelBoys') catDisplay = 'Boys Hostel';
        if (c.category === 'hostelGirls') catDisplay = 'Girls Hostel';
        
        const row = `
            <tr>
                <td><strong>${c.name}</strong></td>
                <td><span style="font-size: 0.85rem; background: var(--bg); padding: 3px 8px; border-radius: 12px; border: 1px solid var(--border); color: var(--text-muted);">${catDisplay}</span></td>
                <td>${c.location || 'N/A'}</td>
                <td><code>${c.email}</code></td>
                <td><code>123456</code></td>
                <td>${c.itemCount}</td>
                 <td><span class="status-badge ${c.status === 'active' ? 'active' : 'inactive'}">${c.status}</span></td>
                <td>
                    <div style="display: flex; gap: 0.5rem;">
                        <button class="btn-toggle" onclick="toggleStatus('${c._id}')">
                            ${c.status === 'active' ? 'Deactivate' : 'Activate'}
                        </button>
                        <button class="btn-toggle" style="color: var(--danger); border-color: var(--danger);" onclick="deleteCanteen('${c._id}', '${c.name.replace(/'/g, "\\'")}')">
                            Delete
                        </button>
                    </div>
                </td>
            </tr>
        `;
        tableBody.insertAdjacentHTML('beforeend', row);
    });
}

window.filterCanteens = function(category, btnElement) {
    // Update active button styles
    if (btnElement) {
        document.querySelectorAll('.filter-btn').forEach(btn => btn.classList.remove('active'));
        btnElement.classList.add('active');
    }

    if (category === 'all') {
        renderCanteensTable(globalCanteensList);
    } else {
        const filtered = globalCanteensList.filter(c => (c.category || 'general') === category);
        renderCanteensTable(filtered);
    }
}

window.toggleTheme = function() {
    const root = document.documentElement;
    const isDark = root.getAttribute('data-theme') === 'dark';
    const newTheme = isDark ? 'light' : 'dark';
    
    root.setAttribute('data-theme', newTheme);
    localStorage.setItem('sa_theme', newTheme);
    
    const themeBtn = document.getElementById('themeToggle');
    if (themeBtn) {
        themeBtn.textContent = newTheme === 'dark' ? '☀️' : '🌙';
    }
    
    // Also dispatch an event in case any charts/graphs need to adapt later
    window.dispatchEvent(new Event('themeChanged'));
};

async function deleteCanteen(id, name) {
    if (!confirm(`Are you sure you want to PERMANENTLY delete "${name}"? This action cannot be undone.`)) {
        return;
    }

    try {
        const res = await fetch(`/api/superadmin/canteens/${id}`, {
            method: 'DELETE'
        });
        if (res.ok) {
            loadData();
        } else {
            const data = await res.json();
            alert(data.message || 'Error deleting canteen');
        }
    } catch (err) {
        console.error('Error deleting canteen:', err);
        alert('Server connection error');
    }
}

async function toggleStatus(id) {
    try {
        const res = await fetch(`/api/superadmin/canteens/${id}/toggle`, {
            method: 'PATCH'
        });
        if (res.ok) {
            loadData();
        }
    } catch (err) {
        console.error('Error toggling status:', err);
    }
}

function openAddModal() {
    document.getElementById('addCanteenModal').style.display = 'flex';
}

function closeAddModal() {
    document.getElementById('addCanteenModal').style.display = 'none';
    document.getElementById('modalErrorMsg').style.display = 'none';
    document.getElementById('successMsg').style.display = 'none';
}

function logout() {
    localStorage.removeItem('super_admin_session');
    window.location.href = 'super-admin-login.html';
}

// Close modal when clicking outside
window.onclick = function(event) {
    const modal = document.getElementById('addCanteenModal');
    if (event.target == modal) {
        closeAddModal();
    }
}
