function initDashboard() {
  console.log('dashboard.js: Initializing Dashboard...');
  requireAuth();

  // false = general campus
  const timeCheck = app.checkTimeBounds(false);

  if (!timeCheck.allowed) {
    document.getElementById('alertContainer').innerHTML = `
      <div class="alert alert-warning">
        <strong>Notice:</strong> ${timeCheck.message} You can browse, but ordering may be restricted.
      </div>
    `;
  }

  const grid = document.getElementById('canteensGrid');

  // Search and Filter State
  let currentFilter = 'all';
  let searchQuery = '';

  window.renderCanteens = function() {
    grid.innerHTML = '';
    
    let filtered = canteensData.general.filter(canteen => {
      const name = canteen.name || "";
      const desc = canteen.desc || canteen.location || "Aditya University Canteen";
      
      const matchSearch = name.toLowerCase().includes(searchQuery) || desc.toLowerCase().includes(searchQuery);
      
      let matchCat = true;
      const descLower = desc.toLowerCase();
      if (currentFilter === 'snacks') {
          matchCat = descLower.includes('snack') || descLower.includes('fast') || descLower.includes('puff') || descLower.includes('cake');
      } else if (currentFilter === 'meals') {
          matchCat = descLower.includes('biryani') || descLower.includes('meal') || descLower.includes('south') || descLower.includes('tiffin');
      } else if (currentFilter === 'beverages') {
          matchCat = descLower.includes('juice') || descLower.includes('shake') || descLower.includes('fruit');
      }
      
      return matchSearch && matchCat;
    });

    if (filtered.length === 0) {
        grid.innerHTML = `<div style="grid-column: 1 / -1; text-align: center; padding: 40px; color: var(--text-secondary);">No canteens found matching your search.</div>`;
        return;
    }

    filtered.forEach(canteen => {
      const status = app.getCanteenStatus(canteen);
      const statusClass = status.isOpen ? (status.urgency ? 'closing-soon' : 'open') : 'closed';
      
      const card = `
        <a href="canteen.html?id=${canteen.id}" class="canteen-card ${!status.isOpen ? 'canteen-closed' : ''}" style="animation: fadeInUp 0.4s ease-out forwards;">
          <div class="canteen-card-image-container">
              <img src="${canteen.image}" class="canteen-card-img" alt="${canteen.name}" style="${!status.isOpen ? 'filter: grayscale(0.8) contrast(0.8);' : ''}">
              <div class="canteen-status-badge ${statusClass}">
                  <span class="status-dot"></span>
                  ${status.text}
              </div>
              <div class="canteen-card-overlay">
                  <span class="view-menu-label">${status.isOpen ? 'View Menu →' : 'Closed'}</span>
              </div>
          </div>
          <div class="canteen-card-body">
            <h3 class="canteen-card-title">${canteen.name}</h3>
            <p class="canteen-card-text">${canteen.desc || canteen.location || "Aditya University Canteen"}</p>
          </div>
        </a>
      `;
      grid.insertAdjacentHTML('beforeend', card);
    });
  };

  // Search Input Listener
  const searchInput = document.getElementById('canteenSearchInput');
  if (searchInput) {
      searchInput.addEventListener('input', (e) => {
          searchQuery = e.target.value.toLowerCase();
          window.renderCanteens();
      });
  }

  // Global Filter Function
  window.filterCanteens = function(category, event) {
      currentFilter = category;
      document.querySelectorAll('.category-pill').forEach(pill => pill.classList.remove('active'));
      if (event && event.target) {
          event.target.classList.add('active');
      }
      window.renderCanteens();
  };

  // Initial Render
  window.renderCanteens();
}


window.addToCartQuick = function(itemId, canteenId) {
    const menu = canteenMenus[canteenId];
    if (!menu) return;
    
    const item = menu.find(i => i.id === itemId);
    if (item) {
        app.addToCart(item, canteenId);
        app.showNotification(`Added ${item.name} to cart`, 'success');
        
        // Slight bounce effect on the button
        if (event && event.target) {
            event.target.textContent = 'Added ✔';
            setTimeout(() => {
                event.target.textContent = 'Add +';
            }, 1000);
        }
    }
};


if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initDashboard);
} else {
  initDashboard();
}
