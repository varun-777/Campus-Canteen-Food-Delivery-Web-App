function initCanteen() {
  console.log('canteen.js: Initializing Canteen...');
  requireAuth();

  // Get Canteen ID from URL
  const urlParams = new URLSearchParams(window.location.search);
  const canteenId = urlParams.get('id');

  if (!canteenId) {
    window.location.href = 'dashboard.html';
  }

  // Find Canteen
  let canteen = null;
  let isHostelCanteen = false;

  [...canteensData.general].forEach(c => {
    if (c.id === canteenId) canteen = c;
  });

  if (!canteen) {
    [...canteensData.hostelBoys, ...canteensData.hostelGirls].forEach(c => {
      if (c.id === canteenId) {
        canteen = c;
        isHostelCanteen = true;
      }
    });
  }

  if (!canteen) {
    window.location.href = 'dashboard.html';
  }

  // Authorization check for hostel canteens
  if (isHostelCanteen && !app.user.isHosteler) {
    alert("You don't have permission to access hostel canteens.");
    window.location.href = 'dashboard.html';
  }

  // Time Check
  const timeCheck = app.checkTimeBounds(isHostelCanteen);

  // Check timing restrictions
  if (!timeCheck.allowed) {
    document.getElementById('alertContainer').innerHTML = `
      <div class="alert alert-warning">
        <strong>Notice:</strong> ${timeCheck.message} Ordering is currently disabled.
      </div>
    `;
  }

  // Render Header
  document.getElementById('canteenHeader').innerHTML = `
    <img src="${canteen.image}" alt="${canteen.name}" class="canteen-cover">
    <div class="canteen-overlay"></div>
    <div class="canteen-info">
      <h1 class="canteen-title">${canteen.name}</h1>
      <div class="canteen-meta">
        <span>★ 4.5 Ratings</span>
        <span>• ${canteen.desc || canteen.location || "Aditya University Canteen"}</span>
      </div>
    </div>
  `;

  // Render Menu
  const menuContainer = document.getElementById('menuContainer');
  let activeMenu = [];

  let showOnlyDiet = false;

  // Show filter toggle if user has dietary preferences
  if (app.user && app.user.dietaryPreferences && app.user.dietaryPreferences.length > 0) {
      const smartFilter = document.getElementById('smartFilterContainer');
      if (smartFilter) smartFilter.style.display = 'flex';
  }

  async function loadMenu() {
      try {
          const res = await fetch('/api/food');
          const allFood = await res.json();
          
          // Match by name
          const canteenFood = allFood.filter(f => f.canteenId && f.canteenId.name.trim().toLowerCase() === canteen.name.trim().toLowerCase());
          
          if (canteenFood && canteenFood.length > 0) {
              activeMenu = canteenFood.map(f => ({
                  id: f._id,
                  name: f.name,
                  price: f.price,
                  image: f.image,
                  desc: f.category,
                  available: f.availability
              }));
          } else {
              activeMenu = typeof canteenMenus !== 'undefined' ? (canteenMenus[canteenId] || genericMenu) : genericMenu;
          }
      } catch (err) {
          console.error('Error fetching backend food:', err);
          activeMenu = typeof canteenMenus !== 'undefined' ? (canteenMenus[canteenId] || genericMenu) : genericMenu;
      }
      renderMenu();
  }

  function renderMenu() {
    menuContainer.innerHTML = '';
    
    // Filter logic
    let itemsToRender = activeMenu;
    if (showOnlyDiet && app.user.dietaryPreferences && app.user.dietaryPreferences.length > 0) {
        itemsToRender = activeMenu.filter(item => {
            if (!item.diet) return true; 
            const prefersVeg = app.user.dietaryPreferences.includes('veg');
            const prefersEgg = app.user.dietaryPreferences.includes('eggetarian');
            const prefersNonVeg = app.user.dietaryPreferences.includes('nonveg');
            if (prefersNonVeg) return true;
            if (item.diet === 'nonveg') return false;
            if (item.diet === 'eggetarian' && !prefersEgg) return false;
            return true;
        });
    }

    if (itemsToRender.length === 0) {
        menuContainer.innerHTML = `<div style="grid-column: 1 / -1; text-align: center; padding: 40px; color: var(--text-secondary);">No items match your dietary filter.</div>`;
        return;
    }

    itemsToRender.forEach(item => {
      // Check if item is in cart
      const cartItem = app.cart.find(i => i.id === item.id);
      const qty = cartItem ? cartItem.qty : 0;

      let actionHtml = '';
      const isAvailable = item.available !== false;

      if (!timeCheck.allowed || !isAvailable) {
        actionHtml = `<span class="badge" style="padding: 8px 12px; background:#f1f2f6; color:#747d8c; border-radius: 20px;">${!isAvailable ? 'Not Available' : 'Closed'}</span>`;
      } else if (qty > 0) {
        actionHtml = `
          <div class="qty-controls">
            <button class="qty-btn" onclick="updateLocalItem('${item.id}', ${qty - 1})">-</button>
            <span class="qty-val">${qty}</span>
            <button class="qty-btn" onclick="updateLocalItem('${item.id}', ${qty + 1})">+</button>
          </div>
        `;
      } else {
        actionHtml = `
          <button class="btn btn-primary" style="padding: 10px 20px; border-radius: 25px; font-weight: 600;" onclick="addLocalItem('${item.id}')">Add to Cart</button>
        `;
      }

      const menuItem = `
        <div class="menu-item">
          <img src="${item.image || getPlaceholder(item.name)}" alt="${item.name}" class="menu-image">
          <div class="menu-content">
            <div class="menu-info">
                <h3>${item.name}</h3>
                <p class="menu-desc">${item.desc}</p>
            </div>
            <div class="menu-footer">
                <div class="menu-price">₹${item.price}</div>
                <div class="menu-action">
                    ${actionHtml}
                </div>
            </div>
          </div>
        </div>
      `;
      menuContainer.insertAdjacentHTML('beforeend', menuItem);
    });
  }

  window.toggleSmartFilter = function() {
      showOnlyDiet = document.getElementById('smartDietFilter').checked;
      renderMenu();
      if (showOnlyDiet) {
          app.showNotification('Filtering by your saved dietary preferences', 'success');
      }
  };

  loadMenu();

  // Export inline variables so HTML generated code can call them
  window.addLocalItem = function (itemId) {
    const item = activeMenu.find(i => i.id === itemId);
    app.addToCart(item, canteenId);
    renderMenu();
  };

  window.updateLocalItem = function (itemId, qty) {
    app.updateQty(itemId, qty);
    renderMenu();
  };
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initCanteen);
} else {
  initCanteen();
}
