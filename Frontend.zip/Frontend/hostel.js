function initHostel() {
  console.log('hostel.js: Initializing Hostel...');
  requireAuth();

  // Authorization check
  if (!app.user.isHosteler) {
    // We already have auth.css loaded which provides .auth-page
    document.body.innerHTML = `
      <div class="auth-page error-state" style="background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);">
        <h1>Access Denied 🛑</h1>
        <p>This area is exclusive for Hostelers.</p>
        <a href="dashboard.html" class="btn btn-primary" style="position: relative; z-index: 10;">Return to Main Canteens</a>
      </div>
    `;
    return; // Stop execution
  }

  // true = hosteler
  const timeCheck = app.checkTimeBounds(true);

  if (!timeCheck.allowed) {
    document.getElementById('alertContainer').innerHTML = `
      <div class="alert alert-warning">
        <strong>Notice:</strong> ${timeCheck.message} You can browse, but ordering may be restricted.
      </div>
    `;
  }

  const grid = document.getElementById('canteensGrid');
  grid.innerHTML = ''; // Clear prior entries to avoid duplicates on re-render

  // determine which list to show
  let canteensList = [];
  if (app.user.hostelType === 'hosteler-boy') {
    canteensList = canteensData.hostelBoys;
  } else if (app.user.hostelType === 'hosteler-girl') {
    canteensList = canteensData.hostelGirls;
  } else {
    canteensList = [...canteensData.hostelBoys, ...canteensData.hostelGirls];
  }

  canteensList.forEach(canteen => {
    const card = `
      <a href="canteen.html?id=${canteen.id}" class="canteen-card">
        <div class="canteen-card-image-container">
            <img src="${canteen.image}" class="canteen-card-img" alt="${canteen.name}">
            <div class="canteen-card-overlay">
                <span class="view-menu-label">View Menu →</span>
            </div>
        </div>
        <div class="canteen-card-body">
          <h3 class="canteen-card-title">${canteen.name}</h3>
          <p class="canteen-card-text">${canteen.desc}</p>
        </div>
      </a>
    `;
    grid.insertAdjacentHTML('beforeend', card);
  });
}

// Expose render function for common.js dynamic loading
window.renderCanteens = initHostel;

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initHostel);
} else {
  initHostel();
}
