// Tab Switching
function switchTab(tab) {
    document.querySelectorAll('.auth-tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.auth-form').forEach(f => {
        f.classList.remove('active');
        f.style.display = 'none'; // Ensure they are hidden
    });

    // Hide auth-tabs if in forgot password mode, show otherwise
    const authTabs = document.querySelector('.auth-tabs');
    if (authTabs) {
        authTabs.style.display = tab === 'forgot' ? 'none' : 'flex';
    }

    if (tab === 'login') {
        document.querySelectorAll('.auth-tab')[0].classList.add('active');
        const loginForm = document.getElementById('loginForm');
        loginForm.classList.add('active');
        loginForm.style.display = 'block';
    } else if (tab === 'register') {
        document.querySelectorAll('.auth-tab')[1].classList.add('active');
        const registerForm = document.getElementById('registerForm');
        registerForm.classList.add('active');
        registerForm.style.display = 'block';
    } else if (tab === 'forgot') {
        const forgotForm = document.getElementById('forgotPasswordForm');
        forgotForm.classList.add('active');
        forgotForm.style.display = 'block';
    }
}

// App namespace extension for registration flow
if (!window.app) window.app = {};
window.app.backToRegisterMain = function() {
    document.getElementById('registerSecurityForm').classList.remove('active');
    document.getElementById('registerSecurityForm').style.display = 'none';
    
    document.getElementById('registerForm').classList.add('active');
    document.getElementById('registerForm').style.display = 'block';
};


document.addEventListener('DOMContentLoaded', () => {
    // Redirect if already logged in
    if (app && app.user) {
        window.location.href = 'dashboard.html';
    }

    // Login Logic
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const email = document.getElementById('loginEmail').value;
            const password = document.getElementById('loginPassword').value;

            try {
                const response = await fetch('http://localhost:5000/api/auth/login', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ email, password })
                });

                const data = await response.json();

                if (response.ok) {
                    app.saveUser(data.user);
                    localStorage.setItem('aditya_token', data.token);
                    window.location.href = 'dashboard.html';
                } else {
                    app.showNotification(data.message || 'Login failed');
                }
            } catch (err) {
                console.error('Login error:', err);
                app.showNotification('Server connection failed');
            }
        });
    }

    // Register Logic - Step 1
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const email = document.getElementById('regEmail').value;
            const password = document.getElementById('regPassword').value;
            const confirmPassword = document.getElementById('regConfirmPassword').value;

            // Email validation
            if (!email.endsWith('@adityauniversity.in')) {
                app.showNotification('Please use your @adityauniversity.in email address');
                return;
            }

            // Password validation
            if (password !== confirmPassword) {
                app.showNotification('Passwords do not match');
                return;
            }

            if (password.length < 6) {
                app.showNotification('Password should be at least 6 characters');
                return;
            }

            // Proceed to Step 2
            registerForm.classList.remove('active');
            registerForm.style.display = 'none';
            
            const securityForm = document.getElementById('registerSecurityForm');
            securityForm.classList.add('active');
            securityForm.style.display = 'block';
        });
    }

    // Register Logic - Step 2 (Security Questions & Final Submit)
    const registerSecurityForm = document.getElementById('registerSecurityForm');
    if (registerSecurityForm) {
        registerSecurityForm.addEventListener('submit', async (e) => {
            e.preventDefault();

            // Get Step 1 Data
            const name = document.getElementById('regName').value;
            const username = document.getElementById('regUsername').value;
            const email = document.getElementById('regEmail').value;
            const password = document.getElementById('regPassword').value;
            const type = document.getElementById('regType').value;

            // Get Step 2 Data
            const securityAnswers = {
                favoriteFood: document.getElementById('regFood').value,
                favoritePerson: document.getElementById('regPerson').value,
                firstSchool: document.getElementById('regSchool').value
            };

            try {
                const response = await fetch('http://localhost:5000/api/auth/register', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        name, username, email, password,
                        isHosteler: type !== 'non-hosteler',
                        hostelType: type,
                        securityAnswers
                    })
                });

                const data = await response.json();

                if (response.ok) {
                    app.saveUser(data.user);
                    localStorage.setItem('aditya_token', data.token);
                    window.location.href = 'dashboard.html';
                } else {
                    app.showNotification(data.message || 'Registration failed');
                }
            } catch (err) {
                console.error('Registration error:', err);
                app.showNotification('Server connection failed');
            }
        });
    }

    // Forgot Password Logic
    const forgotPasswordForm = document.getElementById('forgotPasswordForm');
    if (forgotPasswordForm) {
        forgotPasswordForm.addEventListener('submit', async (e) => {
            e.preventDefault();

            const email = document.getElementById('forgotEmail').value;
            const newPassword = document.getElementById('forgotNewPassword').value;
            const confirmPassword = document.getElementById('forgotConfirmPassword').value;
            
            const securityAnswers = {
                favoriteFood: document.getElementById('forgotFood').value,
                favoritePerson: document.getElementById('forgotPerson').value,
                firstSchool: document.getElementById('forgotSchool').value
            };

            if (newPassword !== confirmPassword) {
                app.showNotification('Passwords do not match');
                return;
            }

            if (newPassword.length < 6) {
                app.showNotification('Password should be at least 6 characters');
                return;
            }

            try {
                const response = await fetch('http://localhost:5000/api/auth/reset-password', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ email, securityAnswers, newPassword })
                });

                const data = await response.json();

                if (response.ok) {
                    app.showNotification('Password reset successfully! Please login.', 'success');
                    forgotPasswordForm.reset();
                    switchTab('login');
                } else {
                    app.showNotification(data.message || 'Reset failed', 'error');
                }
            } catch (err) {
                console.error('Reset password error:', err);
                app.showNotification('Server connection failed', 'error');
            }
        });
    }
});
