document.addEventListener('DOMContentLoaded', () => {
    requireAuth();
    loadProfileDetails();
    setupThemeToggle();
    renderAvatarsGrid();
});

async function updateProfileToBackend(updates) {
    try {
        const response = await fetch('http://localhost:5000/api/auth/profile', {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email: app.user.email, ...updates })
        });
        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.message || 'Failed to update profile');
        }
        return await response.json();
    } catch (err) {
        console.error('Update profile error:', err);
        return null;
    }
}

function loadProfileDetails() {
    if (!app.user) return;
    
    document.getElementById('settingsUsername').textContent = app.user.username || 'User';
    document.getElementById('settingsRollNo').textContent = app.user.rollNo || 'N/A';
    document.getElementById('settingsEmail').textContent = app.user.email || 'N/A';
    
    const avatarChar = app.user.avatar || (app.user.username ? app.user.username.charAt(0).toUpperCase() : 'U');
    const avatarEl = document.getElementById('settingsAvatar');
    avatarEl.textContent = avatarChar;
    if (app.user.avatar) {
        avatarEl.style.background = 'none';
        avatarEl.style.boxShadow = 'none';
        avatarEl.style.fontSize = '60px';
    }
    
    let studentType = 'Unknown';
    if (app.user.studentType) {
        studentType = app.user.studentType;
    } else if (app.user.isHosteler !== undefined) {
        studentType = app.user.isHosteler ? 'Hosteler' : 'Day Scholar';
    }
    
    // Make text more human-readable
    if (studentType === 'hosteler-boy') studentType = 'Hosteler (Boys)';
    if (studentType === 'hosteler-girl') studentType = 'Hosteler (Girls)';
    if (studentType === 'non-hosteler') studentType = 'Day Scholar';
    
    document.getElementById('settingsType').textContent = studentType;

    // Load dietary preferences
    if (app.user.dietaryPreferences && Array.isArray(app.user.dietaryPreferences)) {
        app.user.dietaryPreferences.forEach(pref => {
            const checkbox = document.getElementById(`pref-${pref}`);
            if (checkbox) checkbox.checked = true;
        });
    }
}

async function saveDietaryPreferences() {
    const preferences = [];
    ['veg', 'nonveg', 'eggetarian'].forEach(pref => {
        const checkbox = document.getElementById(`pref-${pref}`);
        if (checkbox && checkbox.checked) {
            preferences.push(checkbox.value);
        }
    });

    const result = await updateProfileToBackend({ dietaryPreferences: preferences });
    
    if (result) {
        app.user.dietaryPreferences = preferences;
        app.saveUser(app.user);
        app.showNotification('Dietary preferences updated', 'success');
    } else {
        app.showNotification('Failed to save dietary preferences');
    }
}

function setupThemeToggle() {
    const toggleInput = document.getElementById('themeToggleCheckbox');
    if (!toggleInput) return;
    
    // Set initial state
    toggleInput.checked = app.theme === 'dark';
    
    // Handle toggle
    toggleInput.addEventListener('change', (e) => {
        if (e.target.checked && app.theme !== 'dark') {
            app.toggleTheme();
        } else if (!e.target.checked && app.theme === 'dark') {
            app.toggleTheme();
        }
    });
}

function toggleEditUsername() {
    const displayEl = document.getElementById('settingsUsername').parentElement;
    const formEl = document.getElementById('editUsernameForm');
    const inputEl = document.getElementById('newUsernameInput');
    
    if (formEl.style.display === 'none') {
        displayEl.style.display = 'none';
        formEl.style.display = 'flex';
        inputEl.value = app.user.username || '';
        inputEl.focus();
    } else {
        displayEl.style.display = 'flex';
        formEl.style.display = 'none';
    }
}

async function saveUsername() {
    const inputEl = document.getElementById('newUsernameInput');
    const newUsername = inputEl.value.trim();
    
    if (!newUsername) {
        app.showNotification('Username cannot be empty');
        return;
    }
    
    if (newUsername.length < 3) {
        app.showNotification('Username must be at least 3 characters');
        return;
    }
    
    const result = await updateProfileToBackend({ username: newUsername });
    if (!result) {
        app.showNotification('Failed to sync username with server');
        return;
    }
    
    // Update local state
    app.user.username = newUsername;
    app.saveUser(app.user);
    
    // Update UI elements
    document.getElementById('settingsUsername').textContent = newUsername;
    
    // Update avatar if needed
    const avatarChar = newUsername.charAt(0).toUpperCase();
    document.getElementById('settingsAvatar').textContent = avatarChar;
    
    // Also update navbar if it exists
    const navUsername = document.querySelector('.user-name-label');
    if (navUsername) navUsername.textContent = newUsername;
    
    // Toggle back to display mode
    toggleEditUsername();
    app.showNotification('Username updated successfully!', 'success');
}

// Avatar Array
const AVATARS = ['🍔', '🍕', '🍣', '🌮', '🥗', '🍦', '🍩', '☕', '🥑', '🥞', '🍱', '🌭', '🍟', '🍜'];

function renderAvatarsGrid() {
    const grid = document.getElementById('avatarsGrid');
    if (!grid) return;
    
    const currentAvatar = app.user.avatar || null;
    let html = '';
    
    // Add default initial option
    const initialChar = app.user.username ? app.user.username.charAt(0).toUpperCase() : 'U';
    const isDefaultSelected = !currentAvatar;
    html += `
        <div onclick="selectAvatar(null)" class="avatar-option ${isDefaultSelected ? 'selected' : ''}" 
             style="width: 50px; height: 50px; display: flex; align-items: center; justify-content: center; 
                    font-size: 1.2rem; font-weight: bold; border-radius: 50%; cursor: pointer; 
                    background: linear-gradient(135deg, var(--primary-color), var(--primary-hover)); color: white;
                    border: ${isDefaultSelected ? '3px solid var(--text-primary)' : '2px solid transparent'}; 
                    transition: transform 0.2s; box-shadow: var(--shadow-sm);">
            ${initialChar}
        </div>
    `;

    AVATARS.forEach(emoji => {
        const isSelected = currentAvatar === emoji;
        html += `
            <div onclick="selectAvatar('${emoji}')" class="avatar-option ${isSelected ? 'selected' : ''}" 
                 style="width: 50px; height: 50px; display: flex; align-items: center; justify-content: center; 
                        font-size: 2rem; border-radius: 50%; cursor: pointer; 
                        background: var(--background-light); 
                        border: ${isSelected ? '3px solid var(--primary-color)' : '2px solid transparent'}; 
                        transition: transform 0.2s; box-shadow: var(--shadow-sm);">
                ${emoji}
            </div>
        `;
    });
    
    grid.innerHTML = html;
}

function selectAvatar(emoji) {
    updateProfileToBackend({ avatar: emoji }).then(result => {
        if (!result) {
            app.showNotification('Failed to sync avatar with server');
            return;
        }

        app.user.avatar = emoji;
        app.saveUser(app.user);
    
    // Update main display
    const avatarEl = document.getElementById('settingsAvatar');
    if (emoji) {
        avatarEl.textContent = emoji;
        avatarEl.style.background = 'none';
        avatarEl.style.boxShadow = 'none';
        avatarEl.style.fontSize = '60px';
    } else {
        avatarEl.textContent = app.user.username ? app.user.username.charAt(0).toUpperCase() : 'U';
        avatarEl.style.background = 'linear-gradient(135deg, var(--primary-color), var(--primary-hover))';
        avatarEl.style.boxShadow = '0 8px 16px rgba(255, 71, 87, 0.2)';
        avatarEl.style.fontSize = '36px';
    }
    
    // Update navbar logic
    const navAvatar = document.querySelector('.user-identity-badge .user-avatar');
    if (navAvatar) {
        navAvatar.textContent = emoji || (app.user.username ? app.user.username.charAt(0).toUpperCase() : 'U');
        if (emoji) {
            navAvatar.style.background = 'none';
            navAvatar.style.boxShadow = 'none';
            navAvatar.style.fontSize = '1.5rem';
        } else {
            navAvatar.style.background = 'linear-gradient(135deg, var(--primary-color), var(--primary-hover))';
            navAvatar.style.boxShadow = '0 4px 8px rgba(255, 71, 87, 0.3)';
            navAvatar.style.fontSize = '1.1rem';
        }
    }
    
    // re-render grid
    renderAvatarsGrid();
    
    app.showNotification('Avatar updated!', 'success');
    });
}

// Change Password Handler
async function changePassword(btnEl) {
    const currentPassword = document.getElementById('currentPassword').value;
    const newPassword = document.getElementById('newPassword').value;
    const confirmPassword = document.getElementById('confirmNewPassword').value;

    if (!currentPassword || !newPassword || !confirmPassword) {
        return app.showNotification('Please fill in all password fields');
    }

    if (newPassword !== confirmPassword) {
        return app.showNotification('New passwords do not match');
    }

    if (newPassword.length < 6) {
        return app.showNotification('New password must be at least 6 characters');
    }

    const originalText = btnEl.textContent;
    btnEl.textContent = 'Updating...';
    btnEl.disabled = true;

    try {
        const response = await fetch('http://localhost:5000/api/auth/change-password', {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                email: app.user.email,
                currentPassword,
                newPassword
            })
        });

        const data = await response.json();

        if (response.ok) {
            app.showNotification('Password updated successfully!', 'success');
            // Clear inputs
            document.getElementById('currentPassword').value = '';
            document.getElementById('newPassword').value = '';
            document.getElementById('confirmNewPassword').value = '';
        } else {
            app.showNotification(data.message || 'Failed to change password');
        }
    } catch (err) {
        console.error('Change password error:', err);
        app.showNotification('Server connection failed');
    } finally {
        btnEl.textContent = originalText;
        btnEl.disabled = false;
    }
}

