document.addEventListener('DOMContentLoaded', () => {
  requireAuth();
  renderNavbar();

  const cartList = document.getElementById('cartItemsList');
  const layout = document.getElementById('checkoutLayout');
  const alertBox = document.getElementById('authAlert');

  if (app.cart.length === 0) {
    layout.style.display = 'none';
    alertBox.style.display = 'block';
  } else {
    renderCart();
    renderDeliveryFields();
  }

  function renderCart() {
    cartList.innerHTML = '';
    app.cart.forEach(item => {
      const div = document.createElement('div');
      div.className = 'cart-item';
      div.innerHTML = `
        <div class="cart-item-info">
          <h4 style="margin-bottom: 5px;">${item.name}</h4>
          <div class="qty-controls" style="margin-top: 8px;">
            <button type="button" class="qty-btn" onclick="updateCheckoutItem('${item.id}', ${item.qty - 1})">-</button>
            <span class="qty-val">${item.qty}</span>
            <button type="button" class="qty-btn" onclick="updateCheckoutItem('${item.id}', ${item.qty + 1})">+</button>
            <button type="button" class="btn" style="margin-left: 15px; padding: 2px 10px; font-size: 0.8rem; background: #ffeaa7; color: #d63031; border: none; border-radius: 4px; font-weight: 600;" onclick="updateCheckoutItem('${item.id}', 0)">Remove</button>
          </div>
        </div>
        <div class="cart-item-price" style="font-weight: 700; font-size: 1.1rem;">
          ₹${item.price * item.qty}
        </div>
      `;
      cartList.appendChild(div);
    });

    const subtotal = app.getCartTotal();
    const currentDeliveryFee = subtotal > 500 ? 0 : app.deliveryFee;
    
    document.getElementById('subTotal').textContent = '₹' + subtotal;
    
    // Add logic to display "Free" with green text if no fee
    const deliveryFeeEl = document.getElementById('deliveryFee');
    if (currentDeliveryFee === 0) {
      deliveryFeeEl.innerHTML = '<span style="color: #22c55e; font-weight: bold;">Free</span>';
    } else {
      deliveryFeeEl.textContent = '₹' + currentDeliveryFee;
    }
    
    document.getElementById('grandTotal').textContent = '₹' + (subtotal + currentDeliveryFee);
  }

  function renderDeliveryFields() {
    const container = document.getElementById('deliveryFields');
    const source = app.getCartSource();

    let html = '';

    if (source === 'both') {
      html += `
        <div class="form-group mb-4">
          <label class="form-label" style="font-weight: 700; color: var(--primary-color);">Delivery Destination</label>
          <p style="font-size: 0.85rem; color: var(--text-secondary); margin-bottom: 10px;">You have items from both Main and Hostel canteens. Where would you like them delivered?</p>
          <div style="display: flex; gap: 20px; margin-top: 10px; background: var(--background-light); padding: 15px; border-radius: 8px; border: 1px solid var(--glass-border);">
            <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; font-weight: 500;">
              <input type="radio" name="destType" value="college" checked onchange="toggleDestFields('college')"> College Bhavan
            </label>
            <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; font-weight: 500;">
              <input type="radio" name="destType" value="hostel" onchange="toggleDestFields('hostel')"> Hostel Block
            </label>
          </div>
        </div>
      `;
    }

    const bhavanOptions = `
      <option value="Bill Gates Bhavan">Bill Gates Bhavan</option>
      <option value="Ratan Tata Bhavan">Ratan Tata Bhavan</option>
      <option value="Edison Bhavan">Edison Bhavan</option>
      <option value="KL Rao Bhavan">KL Rao Bhavan</option>
      <option value="Vishveshwaraya Bhavan">Vishveshwaraya Bhavan</option>
      <option value="Abdul Kalam Bhavan">Abdul Kalam Bhavan</option>
      <option value="CV Raman Bhavan">CV Raman Bhavan</option>
    `;

    const hostelOptions = `
      <option value="Block A">Block A</option>
      <option value="Block B">Block B</option>
      <option value="Block C">Block C</option>
      <option value="Block D">Block D</option>
      <option value="Block E">Block E</option>
      <option value="Block F">Block F</option>
    `;

    html += `
      <div id="collegeFields" style="display: ${source === 'hostel' ? 'none' : 'block'}">
        <div class="form-group">
          <label class="form-label">Select College Bhavan</label>
          <select id="bhavanSelect" class="form-control" ${source === 'main' ? 'required' : ''}>
            <option value="">-- Select Bhavan --</option>
            ${bhavanOptions}
          </select>
        </div>
      </div>
      <div id="hostelFields" style="display: ${source === 'main' || source === 'both' ? 'none' : 'block'}">
        <div class="form-group">
          <label class="form-label">Select Hostel Block</label>
          <select id="blockSelect" class="form-control" ${source === 'hostel' ? 'required' : ''}>
            <option value="">-- Select Block --</option>
            ${hostelOptions}
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Room Number</label>
          <input type="text" id="roomNo" class="form-control" ${source === 'hostel' ? 'required' : ''} placeholder="e.g. 204">
        </div>
      </div>
    `;

    container.innerHTML = html;

    // Export toggle function to window so it can be called from inline onchange
    window.toggleDestFields = function (type) {
      const c = document.getElementById('collegeFields');
      const h = document.getElementById('hostelFields');
      const bs = document.getElementById('bhavanSelect');
      const bls = document.getElementById('blockSelect');
      const rn = document.getElementById('roomNo');

      if (type === 'college') {
        c.style.display = 'block';
        h.style.display = 'none';
        bs.required = true;
        bls.required = false;
        rn.required = false;
      } else {
        c.style.display = 'none';
        h.style.display = 'block';
        bs.required = false;
        bls.required = true;
        rn.required = true;
      }
    };
  }

  window.updateCheckoutItem = function (itemId, qty) {
    app.updateQty(itemId, qty);

    // Check if cart is empty after update
    if (app.cart.length === 0) {
      document.getElementById('checkoutLayout').style.display = 'none';
      document.getElementById('authAlert').style.display = 'block';
    } else {
      renderCart();
      renderDeliveryFields();
    }
  };

  // Handle Form Submit
  const checkoutForm = document.getElementById('checkoutForm');
  if (checkoutForm) {
    checkoutForm.addEventListener('submit', function (e) {
      e.preventDefault();

      const source = app.getCartSource();
      let location = '';
      let roomNo = '';

      if (source === 'main') {
        location = document.getElementById('bhavanSelect').value;
      } else if (source === 'hostel') {
        location = document.getElementById('blockSelect').value;
        roomNo = document.getElementById('roomNo').value;
      } else {
        // Source is 'both'
        const type = document.querySelector('input[name="destType"]:checked').value;
        if (type === 'college') {
          location = document.getElementById('bhavanSelect').value;
        } else {
          location = document.getElementById('blockSelect').value;
          roomNo = document.getElementById('roomNo').value;
        }
      }

      const phone = document.getElementById('phone').value;
      const method = document.getElementById('paymentMethod').value;
      const instructions = document.getElementById('instructions').value;

      const deliveryDetails = {
        location: location,
        roomNo: roomNo,
        phone: phone,
        method: method,
        notes: instructions
      };

      app.placeOrder(deliveryDetails).then(order => {
        if (order) {
          // Show success modal
          document.getElementById('successModal').style.display = 'flex';
        }
      });
    });
  }
});
