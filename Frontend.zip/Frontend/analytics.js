// analytics.js

// Global chart instances so we can destroy them on resize/re-render if needed
let spendingChart = null;
let canteenChart = null;

async function initAnalytics() {
    requireAuth();

    try {
        const response = await fetch(`http://localhost:5000/api/orders/user/${app.user.email}`, {
            headers: { 'Authorization': `Bearer ${localStorage.getItem('aditya_token')}` }
        });

        if (!response.ok) throw new Error('Failed to fetch orders');
        
        const orders = await response.json();
        
        document.getElementById('analyticsLoader').style.display = 'none';
        document.getElementById('analyticsContent').style.display = 'block';

        if (orders.length === 0) {
            document.getElementById('analyticsContent').innerHTML = `
                <div class="card text-center" style="padding: 50px;">
                    <div style="font-size: 3rem; margin-bottom: 20px;">🍽️</div>
                    <h3 style="color: var(--text-primary); margin-bottom: 10px;">No Data Yet</h3>
                    <p style="color: var(--text-secondary);">Start ordering food on campus to see your eating habits mapped out here!</p>
                    <a href="dashboard.html" class="btn btn-primary" style="margin-top: 20px; display: inline-block;">Go to Dashboard</a>
                </div>
            `;
            return;
        }

        processDataAndRender(orders);

    } catch (error) {
        console.error('Analytics Error:', error);
        document.getElementById('analyticsLoader').innerHTML = `
            <div class="alert alert-danger">
                Failed to load analytics data. Please try again later.
            </div>
        `;
    }
}

function processDataAndRender(orders) {
    let totalSpent = 0;
    const itemCounts = {};
    const canteenCounts = {};
    const dates = {};

    // For simplicity, we'll aggregate spending by the last 7 days from today
    const last7Days = Array.from({length: 7}, (_, i) => {
        const d = new Date();
        d.setDate(d.getDate() - (6 - i));
        return {
            dateStr: d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
            dateObj: d,
            spent: 0
        };
    });

    orders.forEach(order => {
        // Skip cancelled orders for spending metrics
        if (order.status === 'Cancelled') return;

        totalSpent += order.total;

        // Process items
        order.items.forEach(item => {
            // Count for top items
            if (!itemCounts[item.name]) itemCounts[item.name] = 0;
            itemCounts[item.name] += item.quantity;

            // Count for top canteens
            if (!canteenCounts[item.canteenName]) canteenCounts[item.canteenName] = 0;
            canteenCounts[item.canteenName] += item.quantity;
        });

        // Process dates for spending chart
        const orderDate = new Date(order.date);
        const orderDateStr = orderDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
        
        // Find if this order matches one of our last 7 days buckets
        const dayBucket = last7Days.find(d => d.dateStr === orderDateStr);
        if (dayBucket) {
            dayBucket.spent += order.total;
        }
    });

    // --- Render Stats Row ---
    document.getElementById('totalSpent').textContent = `₹${totalSpent}`;
    document.getElementById('totalOrders').textContent = orders.filter(o => o.status !== 'Cancelled').length;

    // Sort items to find the top dish
    const sortedItems = Object.entries(itemCounts).sort((a, b) => b[1] - a[1]);
    document.getElementById('topDish').textContent = sortedItems.length > 0 ? sortedItems[0][0] : '-';

    // --- Render Top 5 Items List ---
    const top5 = sortedItems.slice(0, 5);
    const listHtml = top5.map(arr => `
        <div class="top-item">
            <div class="top-item-name">${arr[0]}</div>
            <div class="top-item-count">Ordered ${arr[1]}x</div>
        </div>
    `).join('');
    document.getElementById('topItemsList').innerHTML = listHtml;

    // --- Render Charts ---
    renderSpendingChart(last7Days);
    renderCanteenChart(canteenCounts);
}

function renderSpendingChart(daysData) {
    const ctx = document.getElementById('spendingChart');
    if (!ctx) return;

    // Use root CSS variables for colors if possible, otherwise hardcoded
    const primaryColor = getComputedStyle(document.body).getPropertyValue('--primary').trim() || '#ff4757';
    
    // We want a gradient fill
    const gradient = ctx.getContext('2d').createLinearGradient(0, 0, 0, 400);
    gradient.addColorStop(0, `${primaryColor}66`); // 40% opacity
    gradient.addColorStop(1, `${primaryColor}00`); // 0% opacity

    const isDark = document.body.classList.contains('dark-theme');
    const gridColor = isDark ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.05)';
    const textColor = isDark ? '#b2bec3' : '#636e72';

    spendingChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: daysData.map(d => d.dateStr),
            datasets: [{
                label: 'Spending (₹)',
                data: daysData.map(d => d.spent),
                borderColor: primaryColor,
                backgroundColor: gradient,
                borderWidth: 3,
                pointBackgroundColor: 'white',
                pointBorderColor: primaryColor,
                pointBorderWidth: 2,
                pointRadius: 4,
                fill: true,
                tension: 0.4 // Smooth curves
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: isDark ? '#2d3436' : '#fff',
                    titleColor: isDark ? '#fff' : '#2d3436',
                    bodyColor: isDark ? '#b2bec3' : '#636e72',
                    borderColor: gridColor,
                    borderWidth: 1,
                    padding: 12,
                    displayColors: false,
                    callbacks: {
                        label: function(context) {
                            return '₹' + context.parsed.y;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: { color: gridColor, drawBorder: false },
                    ticks: { color: textColor, callback: value => '₹' + value }
                },
                x: {
                    grid: { display: false, drawBorder: false },
                    ticks: { color: textColor }
                }
            }
        }
    });
}

function renderCanteenChart(canteenCounts) {
    const ctx = document.getElementById('canteenChart');
    if (!ctx) return;

    const labels = Object.keys(canteenCounts);
    const data = Object.values(canteenCounts);

    // Some vibrant campus-friendly colors
    const pieColors = [
        '#ff4757', // Coral red
        '#1e90ff', // Dodger blue
        '#2ed573', // Light green
        '#ffa502', // Orange
        '#3742fa', // Royal blue
        '#ff7f50', // Coral
        '#a4b0be'  // Gray fallback
    ];

    const isDark = document.body.classList.contains('dark-theme');
    const textColor = isDark ? '#b2bec3' : '#636e72';

    canteenChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: labels,
            datasets: [{
                data: data,
                backgroundColor: pieColors.slice(0, labels.length),
                borderWidth: 0,
                hoverOffset: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: '70%', // Make it thin
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        color: textColor,
                        padding: 20,
                        usePointStyle: true,
                        font: { family: 'Inter', size: 12 }
                    }
                }
            }
        }
    });
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initAnalytics);
} else {
    initAnalytics();
}
