// Mock Data & State Management
console.log('common.js: Loading...');

// Using reliable placeholder images with proper dimensions
const getPlaceholder = (text) => `https://placehold.co/600x400/2f3542/ffffff?text=${encodeURIComponent(text)}`;

// Canteens Data
const canteensData = {
    general: [
        { id: 'b1', name: 'Ball Canteen 1', image: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?q=80&w=600&auto=format&fit=crop', desc: 'Famous for biryanis and meals', openTime: '09:30', closeTime: '16:20' },
        { id: 'b2', name: 'Ball Canteen 2', image: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?q=80&w=600&auto=format&fit=crop', desc: 'Fast food & snacks specials', openTime: '09:30', closeTime: '16:20' },
        { id: 'p1', name: 'Pencil Canteen 1', image: 'https://images.unsplash.com/photo-1498837167922-ddd27525d352?q=80&w=600&auto=format&fit=crop', desc: 'Healthy foods and salads', openTime: '09:30', closeTime: '16:20' },
        { id: 'p2', name: 'Pencil Canteen 2', image: 'https://images.unsplash.com/photo-1493770348161-369560ae357d?q=80&w=600&auto=format&fit=crop', desc: 'Premium dine-in experience', openTime: '09:30', closeTime: '16:20' },
        { id: 'bakery', name: 'Bakery', image: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?q=80&w=600&auto=format&fit=crop', desc: 'Fresh cakes, puffs & sweets', openTime: '09:30', closeTime: '16:00' },
        { id: 'eatplay', name: 'Eat and Play', image: 'eat_and_play.png', desc: 'Gaming zone with snacks', openTime: '10:00', closeTime: '18:00' },
        { id: 'rb1', name: 'Ramanujan Bhavan Canteen 1', image: 'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?q=80&w=600&auto=format&fit=crop', desc: 'South Indian authentic tiffins', openTime: '08:00', closeTime: '16:00' },
        { id: 'rb2', name: 'Ramanujan Bhavan Canteen 2', image: 'https://images.unsplash.com/photo-1563379926898-05f4575a45d8?q=80&w=600&auto=format&fit=crop', desc: 'Chinese and Chat', openTime: '11:00', closeTime: '18:00' },
        { id: 'rk', name: 'Rama Krishna Canteen', image: 'https://images.unsplash.com/photo-1540189549336-e6e99c3679fe?q=80&w=600&auto=format&fit=crop', desc: 'All variety foods available', openTime: '09:00', closeTime: '17:00' },
        { id: 'noodles', name: 'Noodles Shop', image: 'https://images.unsplash.com/photo-1552611052-33e04de081de?q=80&w=600&auto=format&fit=crop', desc: 'Spicy noodles and manchuria', openTime: '11:00', closeTime: '18:00' },
        { id: 'fastfood', name: 'Fastfood Shop', image: 'https://images.unsplash.com/photo-1561758033-d89a9ad46330?q=80&w=600&auto=format&fit=crop', desc: 'Burgers, pizzas, wraps', openTime: '11:00', closeTime: '19:00' },
        { id: 'juices', name: 'Juices Shop', image: 'https://images.unsplash.com/photo-1613478223719-2ab802602423?q=80&w=600&auto=format&fit=crop', desc: 'Fresh fruit juices and shakes', openTime: '09:00', closeTime: '18:00' },
        { id: 'fruits', name: 'Fruits Shop', image: 'https://images.unsplash.com/photo-1610832958506-aa56368176cf?q=80&w=600&auto=format&fit=crop', desc: 'Fresh seasonal fruits bowl', openTime: '09:00', closeTime: '17:00' }
    ],
    hostelBoys: [
        { id: 'krishna', name: 'Krishna Canteen', image: 'https://images.unsplash.com/photo-1571091718767-18b5b1457add?q=80&w=600&auto=format&fit=crop', desc: 'Exclusive for Boys Hostel', openTime: '11:00', closeTime: '20:00' },
        { id: 'aparna', name: 'Aparna Canteen', image: 'https://images.unsplash.com/photo-1550547660-d9450f859349?q=80&w=600&auto=format&fit=crop', desc: 'Exclusive for Boys Hostel', openTime: '11:00', closeTime: '20:00' }
    ],
    hostelGirls: [
        { id: 'g1', name: 'Rose Canteen', image: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?q=80&w=600&auto=format&fit=crop', desc: 'Exclusive for Girls Hostel', openTime: '11:00', closeTime: '20:00' },
        { id: 'g2', name: 'Lily Canteen', image: 'https://images.unsplash.com/photo-1552566626-52f8b828add9?q=80&w=600&auto=format&fit=crop', desc: 'Exclusive for Girls Hostel', openTime: '11:00', closeTime: '20:00' },
        { id: 'g3', name: 'Jasmine Canteen', image: 'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?q=80&w=600&auto=format&fit=crop', desc: 'Exclusive for Girls Hostel', openTime: '11:00', closeTime: '20:00' }
    ]
};

// Generic Menu for canteens
const genericMenu = [
    { id: 'm1', name: 'Chicken Biryani', price: 180, image: 'assets/chick.jpg', desc: 'Aromatic basmati rice with spicy chicken', diet: 'nonveg' },
    { id: 'm2', name: 'Veg Fried Rice', price: 100, image: 'https://images.unsplash.com/photo-1603133872878-684f208fb84b?q=80&w=600&auto=format&fit=crop', desc: 'Classic Chinese style fried rice with veggies', diet: 'veg' },
    { id: 'm3', name: 'Masala Dosa', price: 60, image: 'assets/samosa.png', desc: 'Crispy rice crepe with potato masala', diet: 'veg' },
    { id: 'm4', name: 'Paneer Butter Masala', price: 150, image: 'https://images.unsplash.com/photo-1631452180519-c014fe946bc7?q=80&w=600&auto=format&fit=crop', desc: 'Rich and creamy curry with soft cottage cheese', diet: 'veg' },
    { id: 'm5', name: 'Veg Noodles', price: 90, image: 'assets/noodles.jpg', desc: 'Hakka style stir-fried noodles', diet: 'veg' },
    { id: 'm6', name: 'Chicken Manchurian', price: 130, image: 'https://images.unsplash.com/photo-1565557623262-b51c2513a641?q=80&w=600&auto=format&fit=crop', desc: 'Crispy chicken chunks in spicy soy sauce', diet: 'nonveg' },
    { id: 'm7', name: 'Fresh Watermelon Juice', price: 50, image: 'https://images.unsplash.com/photo-1613478223719-2ab802602423?q=80&w=600&auto=format&fit=crop', desc: 'Refreshing juice without added sugar', diet: 'veg' },
    { id: 'm8', name: 'Egg Puff', price: 25, image: 'assets/egg_puff.png', desc: 'Flaky pastry with spicy egg filling', diet: 'eggetarian' }
];

// Specialized Menus
const ballMenu = [
    { id: 'b_biryani', name: 'Chicken Biryani', price: 180, image: 'assets/chick.jpg', desc: 'Signature aromatic biryani', diet: 'nonveg' },
    { id: 'bt1', name: 'Chicken Tikka', price: 220, image: 'https://images.unsplash.com/photo-1565557623262-b51c2513a641?q=80&w=600&auto=format&fit=crop', desc: 'Char-grilled marinated chicken chunks', diet: 'nonveg' },
    { id: 'br1', name: 'Chicken Roll', price: 120, image: 'assets/chicken_roll.png', desc: 'Soft paratha wrapped with spicy chicken', diet: 'nonveg' },
    { id: 'bp1', name: 'Cashew Chicken Pakoda', price: 150, image: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?q=80&w=600&auto=format&fit=crop', desc: 'Crunchy pakoda with cashews and chicken', diet: 'nonveg' },
    { id: 'bo1', name: 'Omelette', price: 40, image: 'assets/omelette.png', desc: 'Fluffy double egg omelette', diet: 'eggetarian' },
    { id: 'bo2', name: 'Bread Omelette', price: 60, image: 'assets/omelette.png', desc: 'Classic street style bread omelette', diet: 'eggetarian' },
    { id: 'ep1', name: 'Egg Puffs', price: 25, image: 'assets/egg_puff.png', desc: 'Crispy pastry with egg filling', diet: 'eggetarian' },
    { id: 'cp1', name: 'Curry Puffs', price: 20, image: 'https://images.unsplash.com/photo-1626074353765-517a681e40be?q=80&w=600&auto=format&fit=crop', desc: 'Spiced potato and peas filling', diet: 'veg' },
    { id: 'vr1', name: 'Veg Roll', price: 80, image: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?q=80&w=600&auto=format&fit=crop', desc: 'Fresh veggies wrapped in a roll', diet: 'veg' },
    { id: 's1', name: 'Samosa', price: 15, image: 'assets/samosa.png', desc: 'Classic crispy potato samosa', diet: 'veg' },
    { id: 'pt1', name: 'Paneer Tikka', price: 180, image: 'assets/samosa.png', desc: 'Marinated paneer cubes grilled to perfection', diet: 'veg' }
];

const fruitMenu = [
    { id: 'f1', name: 'Watermelon Bowl', price: 60, image: 'assets/samosa.png', desc: 'Freshly cut sweet watermelon' },
    { id: 'f2', name: 'Papaya Bowl', price: 50, image: 'https://images.unsplash.com/photo-1526318472351-c75fcf070305?q=80&w=600&auto=format&fit=crop', desc: 'Ripe and healthy papaya slices' },
    { id: 'f3', name: 'Banana (Dozen)', price: 60, image: 'https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?q=80&w=600&auto=format&fit=crop', desc: 'Fresh yellow bananas' },
    { id: 'f4', name: 'Pineapple Slices', price: 70, image: 'https://images.unsplash.com/photo-1550258987-190a2d41a8ba?q=80&w=600&auto=format&fit=crop', desc: 'Sweet and tangy pineapple' },
    { id: 'f5', name: 'Coconut Water', price: 40, image: 'https://images.unsplash.com/photo-1615485500704-8e990f9900f7?q=80&w=600&auto=format&fit=crop', desc: 'Natural refreshing tender coconut' },
    { id: 'f6', name: 'Grapes Bowl', price: 80, image: 'assets/samosa.png', desc: 'Sweet seedless green grapes' },
    { id: 'f7', name: 'Mixed Fruit Salad', price: 100, image: 'assets/samosa.png', desc: 'Assorted seasonal fruits' }
];

const juiceMenu = [
    { id: 'j1', name: 'Fresh Orange Juice', price: 70, image: 'https://images.unsplash.com/photo-1600271886742-f049cd451bba?q=80&w=600&auto=format&fit=crop', desc: 'Pure orange juice with pulp' },
    { id: 'j2', name: 'Watermelon Juice', price: 50, image: 'https://images.unsplash.com/photo-1613478223719-2ab802602423?q=80&w=600&auto=format&fit=crop', desc: 'Cooling watermelon extract' },
    { id: 'j3', name: 'Mango Milkshake', price: 90, image: 'assets/samosa.png', desc: 'Thick and creamy mango shake' },
    { id: 'j4', name: 'Chocolate Milkshake', price: 100, image: 'https://images.unsplash.com/photo-1553177595-4de2bb0842b9?q=80&w=600&auto=format&fit=crop', desc: 'Rich chocolatey goodness' },
    { id: 'j5', name: 'Strawberry Shake', price: 90, image: 'assets/samosa.png', desc: 'Fresh strawberry blended with milk' },
    { id: 'j6', name: 'Pineapple Juice', price: 60, image: 'https://images.unsplash.com/photo-1613478223719-2ab802602423?q=80&w=600&auto=format&fit=crop', desc: 'Freshly squeezed pineapple' },
    { id: 'j7', name: 'Vanilla Milkshake', price: 80, image: 'https://images.unsplash.com/photo-1553177595-4de2bb0842b9?q=80&w=600&auto=format&fit=crop', desc: 'Classic smooth vanilla shake' },
    { id: 'j8', name: 'Badam Milk', price: 50, image: 'assets/samosa.png', desc: 'Traditional almond milk with saffron' }
];

const bakeryMenu = [
    { id: 'bk1', name: 'Assorted Chocolates', price: 50, image: 'https://images.unsplash.com/photo-1549007994-cb92caebd54b?q=80&w=600&auto=format&fit=crop', desc: 'Handcrafted chocolate bars' },
    { id: 'bk2', name: 'Butter Biscuits (Pkt)', price: 40, image: 'https://images.unsplash.com/photo-1558961363-fa8fdf82db35?q=80&w=600&auto=format&fit=crop', desc: 'Crispy and buttery cookies' },
    { id: 'bk3', name: 'Chocolate Cake', price: 70, image: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?q=80&w=600&auto=format&fit=crop', desc: 'Rich layer of chocolate cream' },
    { id: 'bk4', name: 'Red Velvet Pastry', price: 85, image: 'https://images.unsplash.com/photo-1616541823729-00fe0aacd32c?q=80&w=600&auto=format&fit=crop', desc: 'Classic red velvet flavor' },
    { id: 'bk5', name: 'Chicken Puff', price: 35, image: 'assets/egg_puff.png', desc: 'Spicy chicken filling in flaky crust' },
    { id: 'bk6', name: 'Curry Puff', price: 25, image: 'https://images.unsplash.com/photo-1626074353765-517a681e40be?q=80&w=600&auto=format&fit=crop', desc: 'Mixed veg curry filling' },
    { id: 'bk7', name: 'Veg Puff', price: 20, image: 'https://images.unsplash.com/photo-1626074353765-517a681e40be?q=80&w=600&auto=format&fit=crop', desc: 'Light and crispy veg puff' },
    { id: 'bk8', name: 'Onion Samosa (3pc)', price: 30, image: 'assets/samosa.png', desc: 'Mini crunchy onion samosas' }
];

const hostelMenu = [
    { id: 'h1', name: 'Veg Thali', price: 80, image: 'https://images.unsplash.com/photo-1606491956689-2ea866880c84?q=80&w=600&auto=format&fit=crop', desc: 'Rice, Dal, 2 Veg Curries, Sambar, Curd' },
    { id: 'h2', name: 'Chicken Thali', price: 120, image: 'https://images.unsplash.com/photo-1606491956689-2ea866880c84?q=80&w=600&auto=format&fit=crop', desc: 'Rice, Dal, Chicken Curry, Fry, Curd' },
    { id: 'h3', name: 'Maggi', price: 40, image: 'assets/maggi.jpg', desc: 'Classic vegetable masala maggi' },
    { id: 'h4', name: 'Tea', price: 15, image: 'assets/tea.jpg', desc: 'Hot ginger tea' },
    { id: 'h5', name: 'Coffee', price: 20, image: 'assets/coffee.jpg', desc: 'Strong roasted coffee' },
    { id: 'h6', name: 'Bread Omelette', price: 60, image: 'assets/omelette.png', desc: 'Classic hostel night snack' }
];

const pencilMenu = [
    { id: 'pc_cfr', name: 'Chicken Fried Rice', price: 120, image: 'https://images.unsplash.com/photo-1603133872878-684f208fb84b?q=80&w=600&auto=format&fit=crop', desc: 'Wok-tossed rice with tender chicken and veggies' },
    { id: 'pc_vfr', name: 'Veg Fried Rice', price: 90, image: 'https://images.unsplash.com/photo-1516684732162-798a0062be99?q=80&w=600&auto=format&fit=crop', desc: 'Classic vegetable fried rice with fresh greens' },
    { id: 'pc_efr', name: 'Egg Fried Rice', price: 100, image: 'https://images.unsplash.com/photo-1596560548464-f010549b84d7?q=80&w=600&auto=format&fit=crop', desc: 'Aromatic fried rice with scrambled eggs' },
    { id: 'pc_cn', name: 'Chicken Noodles', price: 120, image: 'https://images.unsplash.com/photo-1569718212165-3a8278d5f624?q=80&w=600&auto=format&fit=crop', desc: 'Spicy hakka noodles with chicken chunks' },
    { id: 'pc_vn', name: 'Veg Noodles', price: 90, image: 'assets/noodles.jpg', desc: 'Stir-fried noodles with crisp vegetables' },
    { id: 'pc_en', name: 'Egg Noodles', price: 100, image: 'assets/noodles.jpg', desc: 'Delicious noodles tossed with eggs' },
    { id: 'pc_cr', name: 'Chicken Roll', price: 80, image: 'assets/chicken_roll.png', desc: 'Flavorful chicken filling wrapped in a soft roll' },
    { id: 'pc_vr', name: 'Veg Roll', price: 60, image: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?q=80&w=600&auto=format&fit=crop', desc: 'Fresh vegetable mix wrapped in a crispy roll' }
];

const ramanujanMenu = [
    { id: 'r1', name: 'Idly (4pcs)', price: 40, image: 'assets/idly.jpg', desc: 'Steamed rice cakes with chutney and sambar' },
    { id: 'r2', name: 'Wada (2pcs)', price: 40, image: 'assets/samosa.png', desc: 'Crispy lentil donuts' },
    { id: 'r3', name: 'Masala Dosa', price: 60, image: 'assets/samosa.png', desc: 'Crispy rice crepe with potato masala' },
    { id: 'r4', name: 'Mysore Bajji', price: 50, image: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?q=80&w=600&auto=format&fit=crop', desc: 'Fluffy fried dough balls' }
];

const noodlesMenu = [
    { id: 'n1', name: 'Veg Noodles', price: 90, image: 'assets/noodles.jpg', desc: 'Classic stir-fried veg noodles' },
    { id: 'n2', name: 'Chicken Noodles', price: 120, image: 'https://images.unsplash.com/photo-1569718212165-3a8278d5f624?q=80&w=600&auto=format&fit=crop', desc: 'Spicy noodles with chicken chunks' },
    { id: 'n3', name: 'Veg Manchurian', price: 100, image: 'assets/samosa.png', desc: 'Fried veg balls in spicy gravy' },
    { id: 'n4', name: 'Chicken Manchurian', price: 140, image: 'https://images.unsplash.com/photo-1565557623262-b51c2513a641?q=80&w=600&auto=format&fit=crop', desc: 'Crispy chicken in manchurian sauce' }
];

const fastfoodMenu = [
    { id: 'ff1', name: 'Veg Burger', price: 80, image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?q=80&w=600&auto=format&fit=crop', desc: 'Crispy veg patty with cheese' },
    { id: 'ff2', name: 'Chicken Burger', price: 120, image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?q=80&w=600&auto=format&fit=crop', desc: 'Juicy chicken grill patty' },
    { id: 'ff3', name: 'Cheese Pizza', price: 150, image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?q=80&w=600&auto=format&fit=crop', desc: 'Loaded with mozzarella cheese' },
    { id: 'ff4', name: 'French Fries', price: 60, image: 'assets/samosa.png', desc: 'Crispy salted potato fries' }
];

// Menu Mapping by Canteen ID
const canteenMenus = {
    'b1': ballMenu,
    'b2': ballMenu,
    'p1': pencilMenu,
    'p2': pencilMenu,
    'fruits': fruitMenu,
    'juices': juiceMenu,
    'bakery': bakeryMenu,
    'noodles': noodlesMenu,
    'fastfood': fastfoodMenu,
    'rb1': ramanujanMenu,
    'rb2': noodlesMenu,
    'rk': genericMenu,
    'krishna': hostelMenu,
    'aparna': hostelMenu,
    'g1': hostelMenu,
    'g2': hostelMenu,
    'g3': hostelMenu,
    'eatplay': ballMenu
};

// App State Management
class AppState {
    constructor() {
        this.currentUser = JSON.parse(localStorage.getItem('aditya_user')) || null;
        this.cart = JSON.parse(localStorage.getItem('aditya_cart')) || [];
        this.orders = [];
        this.notifications = [];
        this.deliveryFee = 20;
        this.theme = localStorage.getItem('aditya_theme') || 'light';
        this.init();
    }

    get user() {
        return this.currentUser;
    }

    init() {
        this.loadUser(); // Load user first to set currentUser
        this.applyTheme();
        
        // Start periodic syncing
        if (this.currentUser) {
            this.syncOrders();
            this.syncNotifications();
            setInterval(() => {
                this.syncOrders();
                this.syncNotifications();
            }, 30000); // Sync every 30s
        }
    }

    loadUser() {
        this.currentUser = JSON.parse(localStorage.getItem('aditya_user')) || null;
        if (this.currentUser && this.currentUser.email && !this.currentUser.rollNo) {
            this.currentUser.rollNo = this.currentUser.email.split('@')[0].toUpperCase();
        }
    }

    applyTheme() {
        if (this.theme === 'dark') {
            document.body.classList.add('dark-theme');
        } else {
            document.body.classList.remove('dark-theme');
        }
    }

    toggleTheme() {
        this.theme = this.theme === 'light' ? 'dark' : 'light';
        localStorage.setItem('aditya_theme', this.theme);
        this.applyTheme();
        const themeText = document.getElementById('theme-toggle-text');
        if (themeText) {
            themeText.textContent = this.theme === 'dark' ? 'Dark Mode' : 'Light Mode';
        }
    }

    saveUser(user) {
        this.currentUser = user;
        if (user && user.email) {
            this.currentUser.rollNo = user.email.split('@')[0].toUpperCase();
        }
        localStorage.setItem('aditya_user', JSON.stringify(this.currentUser));
    }

    logout() {
        this.currentUser = null;
        this.cart = [];
        localStorage.removeItem('aditya_user');
        localStorage.removeItem('aditya_cart');
        localStorage.removeItem('aditya_token');
        window.location.href = 'index.html';
    }

    addToCart(item, canteenId) {
        const existingItem = this.cart.find(i => i.id === item.id);
        if (existingItem) {
            existingItem.qty += 1;
        } else {
            this.cart.push({ ...item, qty: 1, canteenId });
        }
        this.saveCart();
        this.updateCartBadge();
    }

    removeFromCart(itemId) {
        this.cart = this.cart.filter(i => i.id !== itemId);
        this.saveCart();
        this.updateCartBadge();
    }

    updateQty(itemId, qty) {
        if (qty <= 0) {
            this.removeFromCart(itemId);
            return;
        }
        const item = this.cart.find(i => i.id === itemId);
        if (item) {
            item.qty = qty;
            this.saveCart();
            this.updateCartBadge();
        }
    }

    clearCart() {
        this.cart = [];
        this.saveCart();
    }

    getCartSource() {
        if (this.cart.length === 0) return null;

        let hasMain = false;
        let hasHostel = false;

        this.cart.forEach(item => {
            const isMain = canteensData.general.some(c => c.id === item.canteenId);
            const isHostel = [...canteensData.hostelBoys, ...canteensData.hostelGirls].some(c => c.id === item.canteenId);

            if (isMain) hasMain = true;
            if (isHostel) hasHostel = true;
        });

        if (hasMain && hasHostel) return 'both';
        if (hasMain) return 'main';
        if (hasHostel) return 'hostel';
        return null;
    }

    saveCart() {
        localStorage.setItem('aditya_cart', JSON.stringify(this.cart));
    }

    getCartTotal() {
        return this.cart.reduce((total, item) => total + (item.price * item.qty), 0);
    }

    updateCartBadge() {
        const badges = document.querySelectorAll('.cart-badge');
        badges.forEach(badge => {
            const count = this.cart.reduce((acc, item) => acc + item.qty, 0);
            badge.textContent = count;
            badge.style.display = count > 0 ? 'flex' : 'none';
        });
    }

    async placeOrder(deliveryDetails) {
        const subtotal = this.getCartTotal();
        const orderData = {
            orderId: 'ORD' + Math.floor(Math.random() * 1000000),
            email: this.currentUser.email,
            items: [...this.cart],
            subtotal: subtotal,
            deliveryFee: this.deliveryFee,
            total: subtotal + this.deliveryFee,
            deliveryDetails: deliveryDetails
        };

        try {
            console.log("Placing order from client:", orderData);
            const response = await fetch('http://localhost:5000/api/orders', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(orderData)
            });

            if (response.ok) {
                const newOrder = await response.json();
                this.orders.unshift(newOrder);
                this.clearCart();
                return newOrder;
            } else {
                const error = await response.json();
                throw new Error(error.message || 'Failed to place order');
            }
        } catch (err) {
            console.error('Order placement error:', err);
            alert('Failed to place order. Check server connection.');
            return null;
        }
    }

    async syncOrders() {
        if (!this.currentUser) return;
        try {
            const response = await fetch(`http://localhost:5000/api/orders/user/${this.currentUser.email}`);
            if (response.ok) {
                this.orders = await response.json();
                // Trigger UI update if on orders page
                if (window.renderOrders) window.renderOrders();
            }
        } catch (err) {
            console.error('Order sync failed:', err);
        }
    }

    async syncNotifications() {
        if (!this.currentUser) return;
        try {
            const response = await fetch(`http://localhost:5000/api/auth/notifications/${this.currentUser.email}`);
            if (response.ok) {
                const notifications = await response.json();
                
                // Check if we have new unread notifications
                const newUnread = notifications.filter(n => !n.isRead).length;
                const oldUnread = this.notifications.filter(n => !n.isRead).length;
                
                this.notifications = notifications;
                this.updateNotificationUI();

                if (newUnread > oldUnread) {
                    // Vibration or sound could go here
                }
            }
        } catch (err) {
            console.error('Notification sync failed:', err);
        }
    }

    updateNotificationUI() {
        const badge = document.getElementById('notificationBadge');
        if (!badge) return;

        const unreadCount = this.notifications.filter(n => !n.isRead).length;
        if (unreadCount > 0) {
            badge.classList.add('active');
            badge.textContent = unreadCount;
            badge.style.display = 'flex';
        } else {
            badge.classList.remove('active');
            badge.textContent = '';
            badge.style.display = 'none';
        }

        const list = document.getElementById('notificationList');
        if (!list) return;

        if (this.notifications.length === 0) {
            list.innerHTML = `<div class="notification-empty">No notifications yet</div>`;
        } else {
            list.innerHTML = this.notifications.slice().reverse().map(n => `
                <div class="notification-item ${!n.isRead ? 'unread' : ''}">
                    <div>${n.text}</div>
                    <div class="notification-time">${new Date(n.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</div>
                </div>
            `).join('');
        }
    }

    toggleNotifications(event) {
        if (event) event.stopPropagation();
        const dropdown = document.getElementById('notificationDropdown');
        if (dropdown) {
            const isActive = dropdown.classList.toggle('active');
            if (isActive) {
                // Close when clicking outside
                const closeHandler = (e) => {
                    if (!dropdown.contains(e.target) && e.target.id !== 'notificationBell') {
                        dropdown.classList.remove('active');
                        document.removeEventListener('click', closeHandler);
                    }
                };
                document.addEventListener('click', closeHandler);
            }
        }
    }

    async markNotificationsAsRead() {
        if (!this.currentUser) return;
        try {
            const response = await fetch('http://localhost:5000/api/auth/notifications/read', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email: this.currentUser.email })
            });
            if (response.ok) {
                this.notifications.forEach(n => n.isRead = true);
                this.updateNotificationUI();
            }
        } catch (err) {
            console.error('Mark read failed:', err);
        }
    }

    async cancelOrder(orderId) {
        if (!confirm('Are you sure you want to cancel this order?')) return;
        
        try {
            const response = await fetch(`http://localhost:5000/api/orders/${orderId}/status`, {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ status: 'Cancelled' })
            });

            if (response.ok) {
                this.showNotification('Order cancelled successfully', 'success');
                await this.syncOrders();
            } else {
                const error = await response.json();
                this.showNotification(error.message || 'Failed to cancel order');
            }
        } catch (err) {
            console.error('Cancellation error:', err);
            this.showNotification('Server connection failed');
        }
    }

    async reorder(orderId) {
        const order = this.orders.find(o => (o.orderId || o.id) === orderId);
        if (!order) return;

        // Clear existing cart and add items from this order
        this.cart = [];
        order.items.forEach(item => {
            // We strip any _id from database if present
            const { id, name, price, qty, canteenId } = item;
            this.cart.push({ id, name, price, qty, canteenId });
        });
        
        this.saveCart();
        this.updateCartBadge();
        this.showNotification('Items added to cart! Redirecting...', 'success');
        
        setTimeout(() => {
            window.location.href = 'checkout.html';
        }, 1500);
    }

    async submitReview(orderId, rating, review) {
        try {
            const response = await fetch(`http://localhost:5000/api/orders/${orderId}/review`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ rating, review })
            });

            if (response.ok) {
                this.showNotification('Thank you for your feedback!', 'success');
                await this.syncOrders();
            } else {
                const error = await response.json();
                this.showNotification(error.message || 'Failed to submit review');
            }
        } catch (err) {
            console.error('Review submission error:', err);
            this.showNotification('Server connection failed');
        }
    }

    checkTimeBounds(isHostel) {
        // Always allowed irrespective of timing
        return { allowed: true, message: '' };
    }

    getCanteenStatus(canteen) {
        // Always open irrespective of timing
        return { isOpen: true, text: 'Open Now' };
    }

    showNotification(message, type = 'error', duration = 5000) {
        let container = document.querySelector('.toast-container');
        if (!container) {
            container = document.createElement('div');
            container.className = 'toast-container';
            document.body.appendChild(container);
        }

        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.innerHTML = `
            <div class="toast-content">${message}</div>
            <div class="toast-progress">
                <div class="toast-progress-bar"></div>
            </div>
        `;

        container.appendChild(toast);

        // Remove after duration
        setTimeout(() => {
            toast.style.animation = 'fadeOutLeft 0.3s ease forwards';
            setTimeout(() => {
                toast.remove();
                if (container.childNodes.length === 0) container.remove();
            }, 300);
        }, duration);
    }
}

const app = new AppState();
console.log('common.js: App initialized', app.currentUser ? app.currentUser.email : 'No user');
// Ensure rollNo is set for existing session
if (app.currentUser && app.currentUser.email && !app.currentUser.rollNo) {
    app.currentUser.rollNo = app.currentUser.email.split('@')[0].toUpperCase();
}

// UI Utilities
function requireAuth() {
    if (!app.currentUser) {
        window.location.href = 'index.html';
    }
}

function renderNavbar() {
    console.log('common.js: renderNavbar called');
    if (!app.currentUser) {
        console.log('common.js: No user found, skipping navbar');
        return;
    }

    const username = app.currentUser.username || 'User';
    const rollNo = app.currentUser.rollNo || (app.currentUser.email ? app.currentUser.email.split('@')[0].toUpperCase() : 'N/A');
    const isHosteler = app.currentUser.isHosteler;
    const path = window.location.pathname.split('/').pop();

    // Create navbar element
    const navElement = document.createElement('nav');
    navElement.className = 'navbar';
    navElement.id = 'main-nav';
    navElement.innerHTML = `
      <div class="container">
        <a href="dashboard.html" class="navbar-brand">
          🍍 <span>Aditya Foods</span>
        </a>
        
        <div class="user-identity-badge">
            <div class="user-avatar" style="${app.currentUser.avatar ? 'background: none; font-size: 1.5rem; box-shadow: none;' : ''}">${app.currentUser.avatar || username.charAt(0).toUpperCase()}</div>
            <div class="user-info-text">
                <span class="user-name-label">${username}</span>
                <span class="user-roll-label">${rollNo}</span>
            </div>
        </div>

        <div class="navbar-nav">
          <a href="dashboard.html" class="nav-link ${path === 'dashboard.html' ? 'active' : ''}">Canteens</a>
          ${isHosteler ? `<a href="hostel.html" class="nav-link ${path === 'hostel.html' ? 'active' : ''}">Hostel Canteens</a>` : ''}
          <a href="orders.html" class="nav-link ${path === 'orders.html' ? 'active' : ''}">Orders</a>
          <a href="analytics.html" class="nav-link ${path === 'analytics.html' ? 'active' : ''}">Analytics</a>
          ${app.currentUser.email === 'admin@aditya.edu' ? `<a href="admin.html" class="nav-link ${path === 'admin.html' ? 'active' : ''}">Admin</a>` : ''}
          <a href="settings.html" class="nav-link settings-btn ${path === 'settings.html' ? 'active' : ''}" title="Settings">⚙️</a>
          
          <div class="notification-bell" id="notificationBell" onclick="app.toggleNotifications(event)">
              🔔
              <div class="notification-badge" id="notificationBadge"></div>
          </div>

          <div class="notification-dropdown" id="notificationDropdown">
              <div class="notification-header">
                  Notifications
                  <span style="font-size: 0.7rem; color: var(--primary-color); cursor: pointer;" onclick="app.markNotificationsAsRead()">Mark all as read</span>
              </div>
              <div class="notification-list" id="notificationList">
                  <!-- Populated by JS -->
              </div>
          </div>

          <a href="checkout.html" class="cart-icon">
            🛒
            <span class="cart-badge" id="cartBadge">0</span>
          </a>
          <button onclick="app.logout()" class="btn btn-outline logout-btn" style="padding: 6px 12px; font-size: 0.85rem; margin-left:10px;">Logout</button>
        </div>
      </div>
    `;

    // Ensure it's at the very top of the body
    const existing = document.getElementById('main-nav') || document.querySelector('.navbar');
    if (existing) existing.remove();

    document.body.prepend(navElement);
    console.log('common.js: Navbar prepended to body');

    // Explicit visibility check
    setTimeout(() => {
        const nav = document.getElementById('main-nav');
        if (nav) {
            const rect = nav.getBoundingClientRect();
            console.log('common.js: Navbar bounding rect:', JSON.stringify(rect));
            if (rect.height === 0) {
                console.warn('common.js: Navbar has 0 height - check CSS');
                nav.style.minHeight = '60px';
                nav.style.backgroundColor = 'white';
            }
        }
    }, 200);

    app.updateCartBadge();
}

async function initApp() {
    console.log('common.js: Initializing App...');
    
    // Fetch dynamic canteens from database
    try {
        const res = await fetch('/api/superadmin/canteens');
        if (res.ok) {
            const dbCanteens = await res.json();
            // Map DB canteens to the format expected by the frontend
            const formattedCanteens = dbCanteens
                .filter(c => c.status === 'active') // Only show active canteens
                .map(c => ({
                    id: c._id,
                    name: c.name,
                    category: c.category || 'general',
                    image: c.image || 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?q=80&w=600&auto=format&fit=crop', // Use uploaded image or default
                    desc: c.location || 'Aditya University Canteen',
                    openTime: '09:30',
                    closeTime: '18:00',
                    isDynamic: true
                }));
            
            // Merge into respective lists avoiding duplicates by name
            formattedCanteens.forEach(newC => {
                const targetArray = newC.category === 'hostelBoys' ? canteensData.hostelBoys : 
                                  newC.category === 'hostelGirls' ? canteensData.hostelGirls : 
                                  canteensData.general;
                
                if (!targetArray.some(oldC => oldC.name === newC.name)) {
                    targetArray.push(newC);
                }
            });
            console.log('common.js: Dynamic canteens loaded', formattedCanteens.length);

            // Trigger re-render if we are on a page that supports it (like dashboard.html)
            if (typeof window.renderCanteens === 'function') {
                console.log('common.js: Triggering re-render for dashboard');
                window.renderCanteens();
            }
        }
    } catch (err) {
        console.error('common.js: Failed to fetch dynamic canteens', err);
    }

    if (app.currentUser) {
        renderNavbar();
    }
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initApp);
} else {
    initApp();
}
