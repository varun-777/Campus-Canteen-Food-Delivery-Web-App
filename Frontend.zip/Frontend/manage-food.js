document.addEventListener('DOMContentLoaded', async () => {
    const canteenData = JSON.parse(localStorage.getItem('canteenData') || '{}');
    if (!canteenData.id) return;

    if (canteenData.name) {
        document.getElementById('canteenNameDisplay').textContent = canteenData.name;
    }

    const foodTableBody = document.getElementById('foodTableBody');
    const foodFormContainer = document.getElementById('foodFormContainer');
    const foodForm = document.getElementById('foodForm');
    const addFoodBtn = document.getElementById('addFoodBtn');
    const cancelBtn = document.getElementById('cancelBtn');
    const formTitle = document.getElementById('formTitle');

    // Load Food
    async function loadFood() {
        try {
            const res = await fetch(`/api/food/${canteenData.id}`);
            const foods = await res.json();
            foodTableBody.innerHTML = '';
            foods.forEach(food => {
                const tr = document.createElement('tr');
                tr.setAttribute('data-id', food._id);
                tr.innerHTML = `
                    <td><img src="${food.image}" alt="${food.name}" class="food-img-preview" onerror="this.src='assets/default-food.png'"></td>
                    <td>${food.name}</td>
                    <td>${food.category}</td>
                    <td>&#8377;${food.price}</td>
                    <td>${food.stock === -1 || food.stock === undefined ? 'Unlimited' : food.stock}</td>
                    <td style="text-align: center;">
                        <span class="status-badge ${food.availability ? 'status-Ready' : 'status-Cancelled'} avail-badge">${food.availability ? 'Available' : 'Out of Stock'}</span>
                    </td>
                    <td>
                        <div style="display: flex; gap: 6px; flex-wrap: wrap; align-items: center;">
                            <button class="btn btn-small" onclick="editFood('${food._id}')">Edit</button>
                            <button class="btn btn-small btn-danger" onclick="deleteFood('${food._id}')">Delete</button>
                            <button class="btn btn-small ${food.availability ? 'btn-danger' : 'btn-success'} toggle-btn" onclick="toggleAvailability('${food._id}', ${!food.availability})" title="${food.availability ? 'Mark Out of Stock' : 'Mark Available'}">
                                ${food.availability ? '⛔ Stock Off' : '✅ Stock On'}
                            </button>
                        </div>
                    </td>
                `;
                foodTableBody.appendChild(tr);
            });
        } catch (err) {
            console.error('Error loading food:', err);
        }
    }

    // Toggle Form
    addFoodBtn.addEventListener('click', () => {
        foodForm.reset();
        document.getElementById('foodId').value = '';
        document.getElementById('foodStock').value = '-1';
        formTitle.textContent = 'Add Food Item';
        foodFormContainer.style.display = 'block';
    });

    cancelBtn.addEventListener('click', () => {
        foodFormContainer.style.display = 'none';
        foodForm.reset();
    });

    // Save Food (Add/Edit)
    foodForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const id = document.getElementById('foodId').value;
        const name = document.getElementById('foodName').value;
        const price = document.getElementById('foodPrice').value;
        const category = document.getElementById('foodCategory').value;
        const imageFile = document.getElementById('foodImageFile').files[0];
        const imageUrl = document.getElementById('foodImage').value;
        const availability = document.getElementById('foodAvailability').checked;
        const stock = document.getElementById('foodStock').value;

        const formData = new FormData();
        formData.append('name', name);
        formData.append('price', price);
        formData.append('category', category);
        formData.append('availability', availability);
        formData.append('stock', stock);
        formData.append('canteenId', canteenData.id);

        if (imageFile) {
            formData.append('imageFile', imageFile);
        } else if (imageUrl) {
            formData.append('imageUrl', imageUrl);
        } else {
            alert('Please upload an image or provide a URL');
            return;
        }

        const url = id ? `/api/food/update/${id}` : '/api/food/add';
        const method = id ? 'PUT' : 'POST';

        try {
            const res = await fetch(url, {
                method,
                body: formData
            });
            if (res.ok) {
                foodFormContainer.style.display = 'none';
                loadFood();
            } else {
                alert('Error saving food item');
            }
        } catch (err) {
            console.error(err);
        }
    });

    // Edit Function
    window.editFood = async (id) => {
        try {
            const res = await fetch(`/api/food/${canteenData.id}`);
            const foods = await res.json();
            const food = foods.find(f => f._id === id);
            
            if (food) {
                document.getElementById('foodId').value = food._id;
                document.getElementById('foodName').value = food.name;
                document.getElementById('foodPrice').value = food.price;
                document.getElementById('foodCategory').value = food.category;
                
                document.getElementById('foodImageFile').value = ''; // Reset file input
                document.getElementById('foodImage').value = food.image.startsWith('/upload') || food.image.startsWith('http') ? food.image : ''; 

                document.getElementById('foodAvailability').checked = food.availability;
                document.getElementById('foodStock').value = food.stock !== undefined ? food.stock : -1;
                
                formTitle.textContent = 'Edit Food Item';
                foodFormContainer.style.display = 'block';
                window.scrollTo(0,0);
            }
        } catch (err) {
            console.error(err);
        }
    };

    // Delete Function
    window.deleteFood = async (id) => {
        if (!confirm('Are you sure you want to delete this food item?')) return;
        try {
            const res = await fetch(`/api/food/delete/${id}`, { method: 'DELETE' });
            if (res.ok) {
                loadFood();
            } else {
                alert('Error deleting food item');
            }
        } catch (err) {
            console.error(err);
        }
    };

    window.toggleAvailability = async (id, newStatus) => {
        try {
            const res = await fetch(`/api/food/${canteenData.id}`);
            const foods = await res.json();
            const food = foods.find(f => f._id === id);
            
            if (food) {
                const formData = new FormData();
                formData.append('name', food.name);
                formData.append('price', food.price);
                formData.append('category', food.category);
                formData.append('imageUrl', food.image); 
                formData.append('availability', newStatus);
                formData.append('stock', food.stock !== undefined ? food.stock : -1);
                formData.append('canteenId', canteenData.id);

                const updateRes = await fetch(`/api/food/update/${id}`, {
                    method: 'PUT',
                    body: formData
                });
                if (updateRes.ok) {
                    // ✅ Update the badge and button in-place — NO full table reload, no screen shake!
                    const row = document.querySelector(`tr[data-id="${id}"]`);
                    if (row) {
                        const badge = row.querySelector('.avail-badge');
                        const toggleBtn = row.querySelector('.toggle-btn');
                        if (newStatus) {
                            badge.className = 'status-badge status-Ready avail-badge';
                            badge.textContent = 'Available';
                            toggleBtn.className = 'btn btn-small btn-danger toggle-btn';
                            toggleBtn.innerHTML = '⛔ Stock Off';
                            toggleBtn.setAttribute('onclick', `toggleAvailability('${id}', false)`);
                        } else {
                            badge.className = 'status-badge status-Cancelled avail-badge';
                            badge.textContent = 'Out of Stock';
                            toggleBtn.className = 'btn btn-small btn-success toggle-btn';
                            toggleBtn.innerHTML = '✅ Stock On';
                            toggleBtn.setAttribute('onclick', `toggleAvailability('${id}', true)`);
                        }
                    }
                } else {
                    alert('Error changing availability');
                }
            }
        } catch (err) {
            console.error(err);
        }
    };

    loadFood();
});
