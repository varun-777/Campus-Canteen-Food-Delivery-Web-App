document.addEventListener('DOMContentLoaded', async () => {
    const canteenData = JSON.parse(localStorage.getItem('canteenData') || '{}');
    if (!canteenData.id) return;

    if (canteenData.name) {
        document.getElementById('canteenNameDisplay').textContent = canteenData.name;
    }

    const orderTableBody = document.getElementById('orderTableBody');

    // Chime Logic
    let lastPendingCount = -1;

    function playDing() {
        try {
            const ctx = new (window.AudioContext || window.webkitAudioContext)();
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.type = 'sine';
            osc.frequency.setValueAtTime(880, ctx.currentTime); // A5
            osc.frequency.exponentialRampToValueAtTime(110, ctx.currentTime + 0.5); 
            gain.gain.setValueAtTime(0.5, ctx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.5);
            osc.start();
            osc.stop(ctx.currentTime + 0.5);
        } catch(e) { console.error('Audio play failed', e); }
    }

    // Load Orders
    async function loadOrders() {
        try {
            const res = await fetch(`/api/canteen-orders/${canteenData.id}`);
            const orders = await res.json();
            orderTableBody.innerHTML = '';
            
            orders.forEach(order => {
                // Determine canteen's share if the order contains mixed items (filtering items for this canteen only)
                const canteenItems = order.items.filter(item => item.canteenId === canteenData.id);
                // If it's a top-level canteenId order, include all items. Otherwise just canteenItems.
                const itemsToDisplay = order.canteenId === canteenData.id ? order.items : canteenItems;
                
                if (itemsToDisplay.length === 0 && order.canteenId !== canteenData.id) return; // Skip if no items for this canteen

                // Format items text
                const itemsText = itemsToDisplay.map(item => `${item.qty}x ${item.name}`).join('<br>');
                
                // Calculate amount specific to canteen (or fallback to full order if not split)
                let amount = order.total;
                if (order.canteenId !== canteenData.id && canteenItems.length > 0) {
                    amount = canteenItems.reduce((acc, curr) => acc + (curr.price * curr.qty), 0);
                }

                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>#${order.orderId}</td>
                    <td>${new Date(order.date).toLocaleString()}</td>
                    <td>${itemsText}</td>
                    <td>₹${parseFloat(amount).toFixed(2)}</td>
                    <td><span class="status-badge status-${order.status}">${order.status}</span></td>
                    <td>
                        <select onchange="updateOrderStatus('${order.orderId}', this.value)">
                            <option value="Pending" ${order.status === 'Pending' ? 'selected' : ''}>Pending</option>
                            <option value="Preparing" ${order.status === 'Preparing' ? 'selected' : ''}>Preparing</option>
                            <option value="Ready" ${order.status === 'Ready' ? 'selected' : ''}>Ready</option>
                            <option value="Delivered" ${order.status === 'Delivered' ? 'selected' : ''}>Delivered</option>
                            <option value="Cancelled" ${order.status === 'Cancelled' ? 'selected' : ''}>Cancelled</option>
                        </select>
                    </td>
                `;
                orderTableBody.appendChild(tr);
            });

            // Check for new pending orders to play chime
            const currentPendingCount = orders.filter(o => o.status === 'Pending').length;
            if (lastPendingCount !== -1 && currentPendingCount > lastPendingCount) {
                // Play chime when new pending orders appear!
                playDing();
            }
            lastPendingCount = currentPendingCount;

        } catch (err) {
            console.error('Error loading orders:', err);
        }
    }

    window.updateOrderStatus = async (orderId, status) => {
        try {
            const res = await fetch(`/api/canteen-orders/${orderId}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ status })
            });

            if (res.ok) {
                loadOrders(); // reload
            } else {
                alert('Error updating order status');
            }
        } catch (err) {
            console.error(err);
        }
    };

    window.exportOrdersCSV = async () => {
        try {
            const res = await fetch(`/api/canteen-orders/${canteenData.id}`);
            const orders = await res.json();
            
            if (orders.length === 0) {
                alert("No orders to export!");
                return;
            }

            // Headers
            let csvContent = "Order ID,Date,Items,Total Amount,Status\n";

            orders.forEach(order => {
                const canteenItems = order.items.filter(item => item.canteenId === canteenData.id);
                const itemsToDisplay = order.canteenId === canteenData.id ? order.items : canteenItems;
                if (itemsToDisplay.length === 0 && order.canteenId !== canteenData.id) return;

                const itemsText = itemsToDisplay.map(item => `${item.qty}x ${item.name}`).join(' | ').replace(/"/g, '""');
                
                let amount = order.total;
                if (order.canteenId !== canteenData.id && canteenItems.length > 0) {
                    amount = canteenItems.reduce((acc, curr) => acc + (curr.price * curr.qty), 0);
                }

                const dateStr = new Date(order.date).toLocaleString().replace(/,/g, '');
                
                csvContent += `${order.orderId},${dateStr},"${itemsText}",${amount},${order.status}\n`;
            });

            // Trigger download
            const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
            const link = document.createElement("a");
            const url = URL.createObjectURL(blob);
            link.setAttribute("href", url);
            link.setAttribute("download", `${canteenData.name.replace(/\s+/g, '_')}_Orders_${new Date().toISOString().split('T')[0]}.csv`);
            link.style.visibility = 'hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);

        } catch (err) {
            console.error('Error exporting CSV:', err);
            alert('Failed to export orders');
        }
    };

    loadOrders();
    
    // Refresh every 10 seconds for real-time feel
    setInterval(loadOrders, 10000);
});
