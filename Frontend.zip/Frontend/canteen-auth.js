document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            const errorMsg = document.getElementById('errorMsg');

            try {
                const res = await fetch('/api/canteen/login', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ email, password })
                });

                const data = await res.json();
                if (res.ok) {
                    localStorage.setItem('canteenToken', data.token);
                    localStorage.setItem('canteenData', JSON.stringify(data.canteen));
                    window.location.href = 'canteen-dashboard.html';
                } else {
                    errorMsg.textContent = data.message || 'Login failed';
                    errorMsg.style.display = 'block';
                }
            } catch (err) {
                errorMsg.textContent = 'Server error. Please try again.';
                errorMsg.style.display = 'block';
            }
        });
    }

    // Protect routing (redirect to login if no token and not on login page)
    const currentPath = window.location.pathname;
    const token = localStorage.getItem('canteenToken');
    if (!currentPath.includes('canteen-login.html') && !token) {
        window.location.href = 'canteen-login.html';
    }
});

function logout() {
    localStorage.removeItem('canteenToken');
    localStorage.removeItem('canteenData');
    window.location.href = 'canteen-login.html';
}

// Dark Mode Logic
function toggleTheme() {
    const isDark = document.body.classList.toggle('dark-mode');
    localStorage.setItem('canteenTheme', isDark ? 'dark' : 'light');
    updateThemeIcon();
}

function updateThemeIcon() {
    const btn = document.getElementById('themeToggleBtn');
    if (btn) {
        btn.innerHTML = document.body.classList.contains('dark-mode') ? '☀️ Light Mode' : '🌙 Dark Mode';
    }
}

// Initialize Theme
const savedTheme = localStorage.getItem('canteenTheme');
if (savedTheme === 'dark') {
    document.body.classList.add('dark-mode');
}
window.addEventListener('DOMContentLoaded', updateThemeIcon);
