const express = require('express');
const router = express.Router();
const Canteen = require('../models/canteenModel');
const Food = require('../models/foodModel');
const Order = require('../models/Order');
const bcrypt = require('bcryptjs');

// Super Admin Login (Hardcoded as requested)
router.post('/login', async (req, res) => {
    const { email, password } = req.body;
    if (email === 'superadmin@system.com' && password === 'admin123') {
        res.json({ message: 'Login successful', token: 'super-admin-token' });
    } else {
        res.status(401).json({ message: 'Invalid credentials' });
    }
});

// Add Canteen
router.post('/add-canteen', async (req, res) => {
    try {
        const { name, location, image, category } = req.body;
        
        // Prevent duplicates
        const existing = await Canteen.findOne({ name });
        if (existing) return res.status(400).json({ message: 'Canteen already exists' });

        // Auto-generate credentials
        const formattedName = name.toLowerCase().replace(/\s+/g, '');
        const email = `${formattedName}@gmail.com`;
        const password = '123456';

        const newCanteen = new Canteen({
            name,
            email,
            password,
            location,
            category: category || 'general',
            image, // Save the Base64 image string
            status: 'active'
        });

        await newCanteen.save();
        res.status(201).json({ 
            message: 'Canteen added successfully', 
            canteen: { name, email, password, location, category, image } 
        });
    } catch (err) {
        res.status(500).json({ message: 'Error adding canteen', error: err.message });
    }
});

// Get All Canteens with Stats
router.get('/canteens', async (req, res) => {
    try {
        const canteens = await Canteen.find();
        const results = await Promise.all(canteens.map(async (c) => {
            const itemCount = await Food.countDocuments({ canteenId: c._id });
            return {
                ...c._doc,
                itemCount
            };
        }));
        res.json(results);
    } catch (err) {
        res.status(500).json({ message: 'Error fetching canteens', error: err.message });
    }
});

// Toggle Canteen Status
router.patch('/canteens/:id/toggle', async (req, res) => {
    try {
        const canteen = await Canteen.findById(req.params.id);
        if (!canteen) return res.status(404).json({ message: 'Canteen not found' });

        canteen.status = canteen.status === 'active' ? 'inactive' : 'active';
        await canteen.save();
        res.json({ message: `Canteen is now ${canteen.status}`, status: canteen.status });
    } catch (err) {
        res.status(500).json({ message: 'Error toggling status', error: err.message });
    }
});

// Delete Canteen Permanently
router.delete('/canteens/:id', async (req, res) => {
    try {
        const canteenId = req.params.id;
        const canteen = await Canteen.findByIdAndDelete(canteenId);
        if (!canteen) return res.status(404).json({ message: 'Canteen not found' });

        // Optionally delete food items associated with this canteen
        await Food.deleteMany({ canteenId: canteenId });
        
        res.json({ message: 'Canteen and associated food items deleted permanently' });
    } catch (err) {
        res.status(500).json({ message: 'Error deleting canteen', error: err.message });
    }
});

// Get Dashboard Stats
router.get('/stats', async (req, res) => {
    try {
        const totalCanteens = await Canteen.countDocuments();
        const totalOrders = await Order.countDocuments();
        const totalFood = await Food.countDocuments();
        res.json({ totalCanteens, totalOrders, totalFood });
    } catch (err) {
        res.status(500).json({ message: 'Error fetching stats', error: err.message });
    }
});

module.exports = router;
