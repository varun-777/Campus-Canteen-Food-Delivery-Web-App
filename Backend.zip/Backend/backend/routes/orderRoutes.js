const express = require('express');
const router = express.Router();
const Order = require('../models/Order');

// Get all orders for a canteen
router.get('/:canteenId', async (req, res) => {
    try {
        const canteenId = req.params.canteenId;
        const mongoose = require('mongoose');
        
        const queryConditions = [
            { 'items.canteenId': canteenId }
        ];

        // Add top-level canteenId condition only if it's a valid ObjectId
        if (mongoose.Types.ObjectId.isValid(canteenId)) {
            queryConditions.push({ canteenId: canteenId });
        }

        // Legacy short-ID support mapping
        const canteenNameMapping = {
            'b1': 'Ball Canteen 1', 'b2': 'Ball Canteen 2', 'p1': 'Pencil Canteen 1', 'p2': 'Pencil Canteen 2',
            'bakery': 'Bakery', 'eatplay': 'Eat and Play', 'rb1': 'Ramanujan Bhavan Canteen 1', 'rb2': 'Ramanujan Bhavan Canteen 2',
            'rk': 'Rama Krishna Canteen', 'noodles': 'Noodles Shop', 'fastfood': 'Fastfood Shop', 'juices': 'Juices Shop',
            'fruits': 'Fruits Shop', 'krishna': 'Krishna Canteen', 'aparna': 'Aparna Canteen', 'g1': 'Rose Canteen',
            'g2': 'Lily Canteen', 'g3': 'Jasmine Canteen'
        };
        const reverseMapping = {};
        for (let key in canteenNameMapping) {
            reverseMapping[canteenNameMapping[key].toLowerCase()] = key;
        }

        const Canteen = require('../models/canteenModel');
        if (mongoose.Types.ObjectId.isValid(canteenId)) {
            const canteen = await Canteen.findById(canteenId);
            if (canteen && canteen.name) {
                const shortId = reverseMapping[canteen.name.toLowerCase()];
                if (shortId) {
                    // Only add to items.canteenId. We CANNOT add shortId to the top-level canteenId
                    // because top-level canteenId is strictly an ObjectId and will trigger a CastError.
                    queryConditions.push({ 'items.canteenId': shortId });
                }
            }
        }

        // Find orders where canteenId matches either at root or inside items (using both ObjectIDs and shortIds)
        const orders = await Order.find({ 
            $or: queryConditions
        }).sort({ date: -1 });
        res.json(orders);
    } catch (err) {
        res.status(500).json({ message: 'Error fetching orders', error: err.message });
    }
});

// Update order status
router.put('/:orderId', async (req, res) => {
    try {
        const { status } = req.body;
        const order = await Order.findOneAndUpdate(
            { orderId: req.params.orderId },
            { status },
            { new: true }
        );
        if (!order) return res.status(404).json({ message: 'Order not found' });
        res.json(order);
    } catch (err) {
        res.status(500).json({ message: 'Error updating order', error: err.message });
    }
});

module.exports = router;
