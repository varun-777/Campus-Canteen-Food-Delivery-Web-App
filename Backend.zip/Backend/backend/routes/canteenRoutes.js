const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const Canteen = require('../models/canteenModel');

// Login
router.post('/login', async (req, res) => {
    try {
        const { email, password } = req.body;
        const canteen = await Canteen.findOne({ email });
        if (!canteen) return res.status(400).json({ message: 'Invalid credentials' });

        const isMatch = await canteen.comparePassword(password);
        if (!isMatch) return res.status(400).json({ message: 'Invalid credentials' });

        const token = jwt.sign({ id: canteen._id }, process.env.JWT_SECRET || 'secret', { expiresIn: '1d' });
        res.json({ token, canteen: { id: canteen._id, name: canteen.name, email: canteen.email } });
    } catch (err) {
        res.status(500).json({ message: 'Server error', error: err.message });
    }
});

// Register
router.post('/register', async (req, res) => {
    try {
        const { name, email, password } = req.body;
        let canteen = await Canteen.findOne({ email });
        if (canteen) return res.status(400).json({ message: 'Canteen already exists' });

        canteen = new Canteen({ name, email, password });
        await canteen.save();

        const token = jwt.sign({ id: canteen._id }, process.env.JWT_SECRET || 'secret', { expiresIn: '1d' });
        res.status(201).json({ token, canteen: { id: canteen._id, name: canteen.name, email: canteen.email } });
    } catch (err) {
        res.status(500).json({ message: 'Server error', error: err.message });
    }
});

// Update Canteen Image
router.patch('/update-image', async (req, res) => {
    try {
        const { id, image } = req.body;
        if (!id) return res.status(400).json({ message: 'Canteen ID is required' });

        const canteen = await Canteen.findByIdAndUpdate(id, { image }, { new: true });
        if (!canteen) return res.status(404).json({ message: 'Canteen not found' });

        res.json({ message: 'Profile image updated successfully', image: canteen.image });
    } catch (err) {
        res.status(500).json({ message: 'Server error', error: err.message });
    }
});

module.exports = router;
