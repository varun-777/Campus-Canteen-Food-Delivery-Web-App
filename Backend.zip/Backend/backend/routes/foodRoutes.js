const express = require('express');
const router = express.Router();
const Food = require('../models/foodModel');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const uploadDir = path.join(__dirname, '../uploads');
if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir);
}

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, uploadDir);
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + path.extname(file.originalname));
    }
});
const upload = multer({ storage: storage });

// Add
router.post('/add', upload.single('imageFile'), async (req, res) => {
    try {
        const { name, price, category, imageUrl, availability, stock, canteenId } = req.body;
        let image = imageUrl;
        if (req.file) {
            image = `/uploads/${req.file.filename}`;
        }
        
        if (!image) return res.status(400).json({ message: 'Image is required' });

        const food = new Food({ 
            name, 
            price: Number(price), 
            category, 
            image, 
            availability: availability === 'true' || availability === true, 
            stock: stock !== undefined ? Number(stock) : -1,
            canteenId 
        });
        await food.save();
        res.status(201).json(food);
    } catch (err) {
        res.status(500).json({ message: 'Server error', error: err.message });
    }
});

// Update
router.put('/update/:id', upload.single('imageFile'), async (req, res) => {
    try {
        const { name, price, category, imageUrl, availability, stock } = req.body;
        
        const updateData = {
            name,
            price: Number(price),
            category,
            availability: availability === 'true' || availability === true
        };
        
        if (stock !== undefined) {
            updateData.stock = Number(stock);
        }
        
        if (req.file) {
            updateData.image = `/uploads/${req.file.filename}`;
        } else if (imageUrl) {
            updateData.image = imageUrl;
        }

        const food = await Food.findByIdAndUpdate(req.params.id, updateData, { new: true });
        if (!food) return res.status(404).json({ message: 'Food not found' });
        res.json(food);
    } catch (err) {
        res.status(500).json({ message: 'Server error', error: err.message });
    }
});

// Delete
router.delete('/delete/:id', async (req, res) => {
    try {
        const food = await Food.findByIdAndDelete(req.params.id);
        if (!food) return res.status(404).json({ message: 'Food not found' });
        res.json({ message: 'Food item deleted successfully' });
    } catch (err) {
        res.status(500).json({ message: 'Server error', error: err.message });
    }
});

// Get by canteen
router.get('/:canteenId', async (req, res) => {
    try {
        const foods = await Food.find({ canteenId: req.params.canteenId });
        res.json(foods);
    } catch (err) {
        res.status(500).json({ message: 'Server error', error: err.message });
    }
});

// Get all food items (useful for student dashboard if showing all)
router.get('/', async (req, res) => {
    try {
        const foods = await Food.find().populate('canteenId', 'name');
        res.json(foods);
    } catch (err) {
        res.status(500).json({ message: 'Server error', error: err.message });
    }
});

module.exports = router;
