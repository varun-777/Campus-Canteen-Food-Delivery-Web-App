const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const path = require('path');
const dotenv = require('dotenv');
const jwt = require('jsonwebtoken');
const User = require('./models/User');
const Order = require('./models/Order');

const canteenRoutes = require('./routes/canteenRoutes');
const foodRoutes = require('./routes/foodRoutes');
const orderRoutes = require('./routes/orderRoutes');
const superAdminRoutes = require('./routes/superAdminRoutes');

// Load .env from project root (one level up from backend/)
dotenv.config({ path: path.join(__dirname, '../.env') });

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());
// Serve frontend static files from frontend/ folder
app.use(express.static(path.join(__dirname, '../frontend')));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Mount Admin Routes
app.use('/api/canteen', canteenRoutes);
app.use('/api/food', foodRoutes);
app.use('/api/canteen-orders', orderRoutes);
app.use('/api/superadmin', superAdminRoutes);

// Database Connection
mongoose.connect(process.env.MONGODB_URI)
    .then(() => console.log('✅ Connected to MongoDB'))
    .catch(err => console.error('❌ MongoDB connection error:', err));

// --- Auth Routes ---

// Register
app.post('/api/auth/register', async (req, res) => {
    try {
        const { name, username, email, password, isHosteler, hostelType, securityAnswers } = req.body;

        let userByEmail = await User.findOne({ email: { $regex: new RegExp("^" + email + "$", "i") } });
        if (userByEmail) {
            console.log("Found existing user with email:", email);
            return res.status(400).json({ message: 'Email already registered' });
        }
        
        let userByUsername = await User.findOne({ username: { $regex: new RegExp("^" + username + "$", "i") } });
        if (userByUsername) {
            console.log("Found existing user with username:", username);
            return res.status(400).json({ message: 'Username is already taken' });
        }

        // Ensure security answers are provided and lowercased for consistency
        if (!securityAnswers || !securityAnswers.favoriteFood || !securityAnswers.favoritePerson || !securityAnswers.firstSchool) {
             return res.status(400).json({ message: 'Please answer all security questions' });
        }

        const formattedAnswers = {
            favoriteFood: securityAnswers.favoriteFood.toLowerCase().trim(),
            favoritePerson: securityAnswers.favoritePerson.toLowerCase().trim(),
            firstSchool: securityAnswers.firstSchool.toLowerCase().trim()
        };

        const user = new User({ name, username, email, password, isHosteler, hostelType, securityAnswers: formattedAnswers });
        await user.save();

        const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: '1d' });
        res.status(201).json({ token, user: { name, username, email, isHosteler, hostelType, avatar: user.avatar, notifications: user.notifications } });
    } catch (err) {
        console.error('Registration Error Details:', err);
        // Handle unexpected mongo duplicate key errors just in case
        if (err.code === 11000) {
            return res.status(400).json({ message: 'Account with these details already exists.' });
        }
        res.status(500).json({ message: 'Server error', error: err.message });
    }
});

// Login
app.post('/api/auth/login', async (req, res) => {
    try {
        const { email, password } = req.body;

        const user = await User.findOne({ email: { $regex: new RegExp("^" + email + "$", "i") } });
        if (!user) return res.status(400).json({ message: 'Email was not found' });

        const isMatch = await user.comparePassword(password);
        if (!isMatch) return res.status(400).json({ message: 'Password is incorrect' });

        const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: '1d' });
        res.status(200).json({ token, user: { name: user.name, username: user.username, email, isHosteler: user.isHosteler, hostelType: user.hostelType, avatar: user.avatar, notifications: user.notifications } });
    } catch (err) {
        res.status(500).json({ message: 'Server error', error: err.message });
    }
});

// Update Profile
app.put('/api/auth/profile', async (req, res) => {
    try {
        const { email, username, avatar } = req.body;
        const user = await User.findOne({ email: { $regex: new RegExp("^" + email + "$", "i") } });
        if (!user) return res.status(404).json({ message: 'User not found' });

        if (username) user.username = username;
        if (avatar !== undefined) user.avatar = avatar;

        await user.save();
        res.status(200).json({ message: 'Profile updated successfully', user: { name: user.name, username: user.username, email: user.email, isHosteler: user.isHosteler, hostelType: user.hostelType, avatar: user.avatar, notifications: user.notifications } });
    } catch (err) {
        res.status(500).json({ message: 'Server error', error: err.message });
    }
});

// Change Password
app.put('/api/auth/change-password', async (req, res) => {
    try {
        const { email, currentPassword, newPassword } = req.body;
        const user = await User.findOne({ email: { $regex: new RegExp("^" + email + "$", "i") } });
        if (!user) return res.status(404).json({ message: 'User not found' });

        const isMatch = await user.comparePassword(currentPassword);
        if (!isMatch) return res.status(400).json({ message: 'Current password is incorrect' });

        user.password = newPassword;
        await user.save();
        res.status(200).json({ message: 'Password updated successfully' });
    } catch (err) {
        res.status(500).json({ message: 'Server error', error: err.message });
    }
});

// Reset Password (Forgot Password Flow)
app.post('/api/auth/reset-password', async (req, res) => {
    try {
        const { email, securityAnswers, newPassword } = req.body;
        const user = await User.findOne({ email: { $regex: new RegExp("^" + email + "$", "i") } });
        
        if (!user) return res.status(404).json({ message: 'User not found' });

        if (!securityAnswers || !securityAnswers.favoriteFood || !securityAnswers.favoritePerson || !securityAnswers.firstSchool) {
             return res.status(400).json({ message: 'Please answer all security questions' });
        }

        // Check if user has security answers set up
        if (!user.securityAnswers || !user.securityAnswers.favoriteFood) {
             return res.status(400).json({ message: 'Security questions not set up for this account. Please contact admin.' });
        }

        const matchFood = user.securityAnswers.favoriteFood === securityAnswers.favoriteFood.toLowerCase().trim();
        const matchPerson = user.securityAnswers.favoritePerson === securityAnswers.favoritePerson.toLowerCase().trim();
        const matchSchool = user.securityAnswers.firstSchool === securityAnswers.firstSchool.toLowerCase().trim();

        if (!matchFood || !matchPerson || !matchSchool) {
            return res.status(400).json({ message: 'Incorrect answers to security questions' });
        }

        user.password = newPassword;
        await user.save();
        res.status(200).json({ message: 'Password reset successfully. You can now login.' });
    } catch (err) {
        res.status(500).json({ message: 'Server error', error: err.message });
    }
});

// Get Notifications
app.get('/api/auth/notifications/:email', async (req, res) => {
    try {
        const user = await User.findOne({ email: { $regex: new RegExp("^" + req.params.email + "$", "i") } });
        if (!user) return res.status(404).json({ message: 'User not found' });
        res.json(user.notifications);
    } catch (err) {
        res.status(500).json({ message: 'Server error', error: err.message });
    }
});

// Clear/Mark Read Notifications
app.post('/api/auth/notifications/read', async (req, res) => {
    try {
        const { email } = req.body;
        const user = await User.findOne({ email: { $regex: new RegExp("^" + email + "$", "i") } });
        if (!user) return res.status(404).json({ message: 'User not found' });
        
        user.notifications.forEach(n => n.isRead = true);
        await user.save();
        res.status(200).json({ message: 'Notifications marked as read' });
    } catch (err) {
        res.status(500).json({ message: 'Server error', error: err.message });
    }
});

// Update Profile (Avatar, Username, Dietary)
app.put('/api/auth/profile', async (req, res) => {
    try {
        const { email, avatar, username, dietaryPreferences } = req.body;
        
        let updateData = {};
        if (avatar !== undefined) updateData.avatar = avatar;
        if (username) updateData.username = username;
        if (dietaryPreferences !== undefined) updateData.dietaryPreferences = dietaryPreferences;

        if (Object.keys(updateData).length === 0) {
            return res.status(400).json({ message: 'No update data provided' });
        }

        const user = await User.findOneAndUpdate(
            { email: { $regex: new RegExp("^" + email + "$", "i") } }, 
            updateData, 
            { new: true }
        );
        
        if (!user) return res.status(404).json({ message: 'User not found' });

        res.json({ message: 'Profile updated', user: { avatar: user.avatar, username: user.username, dietaryPreferences: user.dietaryPreferences } });
    } catch (err) {
        console.error('Update profile error:', err);
        res.status(500).json({ message: 'Server error' });
    }
});

// --- Order Routes ---

// Place Order
app.post('/api/orders', async (req, res) => {
    try {
        const { orderId, email, items, subtotal, deliveryFee, total, deliveryDetails } = req.body;

        const user = await User.findOne({ email: { $regex: new RegExp("^" + email + "$", "i") } });
        if (!user) return res.status(404).json({ message: 'User not found' });

        const canteenNameMapping = {
            'b1': 'Ball Canteen 1', 'b2': 'Ball Canteen 2', 'p1': 'Pencil Canteen 1', 'p2': 'Pencil Canteen 2',
            'bakery': 'Bakery', 'eatplay': 'Eat and Play', 'rb1': 'Ramanujan Bhavan Canteen 1', 'rb2': 'Ramanujan Bhavan Canteen 2',
            'rk': 'Rama Krishna Canteen', 'noodles': 'Noodles Shop', 'fastfood': 'Fastfood Shop', 'juices': 'Juices Shop',
            'fruits': 'Fruits Shop', 'krishna': 'Krishna Canteen', 'aparna': 'Aparna Canteen', 'g1': 'Rose Canteen',
            'g2': 'Lily Canteen', 'g3': 'Jasmine Canteen'
        };
        const Canteen = require('./models/canteenModel');

        // Map short IDs to ObjectIDs
        for (let item of items) {
            if (item.canteenId && item.canteenId.length < 24) {
               const fullName = canteenNameMapping[item.canteenId];
               if (fullName) {
                   const c = await Canteen.findOne({ name: { $regex: new RegExp("^" + fullName + "$", "i") } });
                   if (c) {
                       item.canteenId = c._id.toString();
                   }
               }
            }
        }

        // Also figure out top-level canteenId if all items share the same canteenId
        let topCanteenId = undefined;
        if (items.length > 0 && items.every(i => i.canteenId === items[0].canteenId)) {
            topCanteenId = items[0].canteenId;
        }

        // Auto-Deplete Inventory Limits
        const Food = require('./models/foodModel');
        for (let item of items) {
            if (item.canteenId && item.canteenId.length >= 24) {
                const meal = await Food.findOne({ name: item.name, canteenId: item.canteenId });
                if (meal && meal.stock !== undefined && meal.stock !== -1) {
                    meal.stock -= item.qty;
                    if (meal.stock <= 0) {
                        meal.stock = 0;
                        meal.availability = false; // Mark out of stock automatically
                    }
                    await meal.save();
                }
            }
        }

        const newOrder = new Order({
            orderId,
            userId: user._id,
            canteenId: topCanteenId,
            items,
            subtotal,
            deliveryFee,
            total,
            deliveryDetails
        });

        await newOrder.save();
        
        // Add Notification via updateOne to bypass validation for legacy users missing securityAnswers
        await User.updateOne(
            { _id: user._id },
            { $push: { notifications: { text: `Order #${orderId} has been placed successfully!`, type: 'success' } } }
        );

        res.status(201).json(newOrder);
    } catch (err) {
        console.error('Order Placement Error Details:', err);
        res.status(500).json({ message: 'Error placing order', error: err.message });
    }
});

// Get User Orders
app.get('/api/orders/user/:email', async (req, res) => {
    try {
        const user = await User.findOne({ email: { $regex: new RegExp("^" + req.params.email + "$", "i") } });
        if (!user) return res.status(404).json({ message: 'User not found' });

        const orders = await Order.find({ userId: user._id }).sort({ date: -1 });
        res.json(orders);
    } catch (err) {
        res.status(500).json({ message: 'Error fetching orders', error: err.message });
    }
});

// --- Admin Routes ---

// Get All Orders (Admin)
app.get('/api/admin/orders', async (req, res) => {
    try {
        const orders = await Order.find().sort({ date: -1 });
        res.json(orders);
    } catch (err) {
        res.status(500).json({ message: 'Error fetching all orders', error: err.message });
    }
});

// Update Order Status
app.patch('/api/orders/:orderId/status', async (req, res) => {
    try {
        const { status } = req.body;
        const order = await Order.findOneAndUpdate(
            { orderId: req.params.orderId },
            { status },
            { new: true }
        );
        if (!order) return res.status(404).json({ message: 'Order not found' });

        // Add Notification to User
        const user = await User.findById(order.userId);
        if (user) {
            user.notifications.push({
                text: `Your Order #${order.orderId} status is now: ${status}`,
                type: status === 'Delivered' ? 'success' : (status === 'Cancelled' ? 'error' : 'info')
            });
            await user.save();
        }

        res.json(order);
    } catch (err) {
        res.status(500).json({ message: 'Error updating order status', error: err.message });
    }
});

// Submit Review
app.put('/api/orders/:orderId/review', async (req, res) => {
    try {
        const { rating, review } = req.body;
        const order = await Order.findOneAndUpdate(
            { orderId: req.params.orderId },
            { rating, review },
            { new: true }
        );
        if (!order) return res.status(404).json({ message: 'Order not found' });
        res.json(order);
    } catch (err) {
        res.status(500).json({ message: 'Error submitting review', error: err.message });
    }
});

// Start Server
app.listen(PORT, () => {
    console.log(`🚀 Server running on http://localhost:${PORT}`);
});
