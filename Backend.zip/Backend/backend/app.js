// Mock Data & State Management

// Canteens Data
const canteensData = {
  general: [
    { id: 'b1', name: 'Ball Canteen 1', image: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&q=80&w=600', desc: 'Famous for biryanis and meals' },
    { id: 'b2', name: 'Ball Canteen 2', image: 'https://images.unsplash.com/photo-1590846406792-0adc7f938f1d?auto=format&fit=crop&q=80&w=600', desc: 'Fast food & snacks specials' },
    { id: 'p1', name: 'Pencil Canteen 1', image: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&q=80&w=600', desc: 'Healthy foods and salads' },
    { id: 'p2', name: 'Pencil Canteen 2', image: 'https://images.unsplash.com/photo-1565299585323-38d6b0865bcc?auto=format&fit=crop&q=80&w=600', desc: 'Premium dine-in experience' },
    { id: 'bakery', name: 'Bakery', image: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&q=80&w=600', desc: 'Fresh cakes, puffs & sweets' },
    { id: 'eatplay', name: 'Eat and Play', image: 'https://images.unsplash.com/photo-1511690656952-34342bb7c2f2?auto=format&fit=crop&q=80&w=600', desc: 'Gaming zone with snacks' },
    { id: 'rb1', name: 'Ramanujan Bhavan Canteen 1', image: 'https://images.unsplash.com/photo-1626202452771-8bc682d338fb?auto=format&fit=crop&q=80&w=600', desc: 'South Indian authentic tiffins' },
    { id: 'rb2', name: 'Ramanujan Bhavan Canteen 2', image: 'https://images.unsplash.com/photo-1589302168068-964664d93cb0?auto=format&fit=crop&q=80&w=600', desc: 'Chinese and Chat' },
    { id: 'rk', name: 'Rama Krishna Canteen', image: 'https://images.unsplash.com/photo-1414235077428-338988647d77?auto=format&fit=crop&q=80&w=600', desc: 'All variety foods available' },
    { id: 'noodles', name: 'Noodles Shop', image: 'https://images.unsplash.com/photo-1598514982205-f36b96d1e8d4?auto=format&fit=crop&q=80&w=600', desc: 'Spicy noodles and manchuria' },
    { id: 'fastfood', name: 'Fastfood Shop', image: 'https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&q=80&w=600', desc: 'Burgers, pizzas, wraps' },
    { id: 'juices', name: 'Juices Shop', image: 'https://images.unsplash.com/photo-1600271886742-f049cd451bba?auto=format&fit=crop&q=80&w=600', desc: 'Fresh fruit juices and shakes' },
    { id: 'fruits', name: 'Fruits Shop', image: 'https://images.unsplash.com/photo-1610832958506-aa56368176cf?auto=format&fit=crop&q=80&w=600', desc: 'Fresh seasonal fruits bowl' }
  ],
  hostelBoys: [
    { id: 'krishna', name: 'Krishna Canteen', image: 'https://images.unsplash.com/photo-1514326640560-7d063ef2aed5?auto=format&fit=crop&q=80&w=600', desc: 'Exclusive for Boys Hostel' },
    { id: 'aparna', name: 'Aparna Canteen', image: 'https://images.unsplash.com/photo-1559847844-5315695dadae?auto=format&fit=crop&q=80&w=600', desc: 'Exclusive for Boys Hostel' }
  ],
  hostelGirls: [
    { id: 'g1', name: 'Rose Canteen', image: 'https://images.unsplash.com/photo-1565557623262-b51c2513a641?auto=format&fit=crop&q=80&w=600', desc: 'Exclusive for Girls Hostel' },
    { id: 'g2', name: 'Lily Canteen', image: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&q=80&w=600', desc: 'Exclusive for Girls Hostel' },
    { id: 'g3', name: 'Jasmine Canteen', image: 'https://images.unsplash.com/photo-1533777857889-4be7c70b33f7?auto=format&fit=crop&q=80&w=600', desc: 'Exclusive for Girls Hostel' }
  ]
};

// Generic Menu for canteens
const genericMenu = [
  { id: 'm1', name: 'Chicken Biryani', price: 180, desc: 'Aromatic basmati rice with spicy chicken' },
  { id: 'm2', name: 'Veg Fried Rice', price: 100, desc: 'Classic Chinese style fried rice with veggies' },
  { id: 'm3', name: 'Masala Dosa', price: 60, desc: 'Crispy crepe filled with potato masala' },
  { id: 'm4', name: 'Paneer Butter Masala', price: 150, desc: 'Rich and creamy curry with soft cottage cheese' },
  { id: 'm5', name: 'Veg Noodles', price: 90, desc: 'Hakka style stir-fried noodles' },
  { id: 'm6', name: 'Chicken Manchurian', price: 130, desc: 'Crispy chicken chunks in spicy soy sauce' },
  { id: 'm7', name: 'Fresh Watermelon Juice', price: 50, desc: 'Refreshing juice without added sugar' },
  { id: 'm8', name: 'Egg Puff', price: 25, desc: 'Flaky pastry with spicy egg filling' }
];

// App State Management
class AppState {
  constructor() {
    this.user = JSON.parse(localStorage.getItem('aditya_user')) || null;
    this.cart = JSON.parse(localStorage.getItem('aditya_cart')) || [];
    this.orders = JSON.parse(localStorage.getItem('aditya_orders')) || [];
    this.deliveryFee = 20; // Default delivery charge
  }

  saveUser(user) {
    this.user = user;
    localStorage.setItem('aditya_user', JSON.stringify(user));
  }

  logout() {
    this.user = null;
    this.cart = [];
    localStorage.removeItem('aditya_user');
    localStorage.removeItem('aditya_cart');
    window.location.href = 'index.html';
  }

  addToCart(item, canteenId) {
    const existingItem = this.cart.find(i => i.id === item.id);
    if (existingItem) {
      existingItem.qty += 1;
    } else {
      this.cart.push({ ...item, qty: 1, canteenId });
    }
    this.saveCart();
    this.updateCartBadge();
  }

  removeFromCart(itemId) {
    this.cart = this.cart.filter(i => i.id !== itemId);
    this.saveCart();
    this.updateCartBadge();
  }

  updateQty(itemId, qty) {
    if (qty <= 0) {
      this.removeFromCart(itemId);
      return;
    }
    const item = this.cart.find(i => i.id === itemId);
    if (item) {
      item.qty = qty;
      this.saveCart();
      this.updateCartBadge();
    }
  }

  clearCart() {
    this.cart = [];
    this.saveCart();
  }

  saveCart() {
    localStorage.setItem('aditya_cart', JSON.stringify(this.cart));
  }

  getCartTotal() {
    return this.cart.reduce((total, item) => total + (item.price * item.qty), 0);
  }

  updateCartBadge() {
    const badges = document.querySelectorAll('.cart-badge');
    badges.forEach(badge => {
      const count = this.cart.reduce((acc, item) => acc + item.qty, 0);
      badge.textContent = count;
      badge.style.display = count > 0 ? 'flex' : 'none';
    });
  }

  async placeOrder(deliveryDetails) {
    const subtotal = this.getCartTotal();
    const currentDeliveryFee = subtotal > 500 ? 0 : this.deliveryFee;
    const orderData = {
      orderId: 'ORD' + Math.floor(Math.random() * 1000000),
      email: this.user.email,
      items: [...this.cart],
      subtotal: subtotal,
      deliveryFee: currentDeliveryFee,
      total: subtotal + currentDeliveryFee,
      deliveryDetails: deliveryDetails,
      status: 'Preparing'
    };

    try {
      const response = await fetch('http://localhost:5000/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(orderData)
      });

      if (response.ok) {
        const newOrder = await response.json();
        this.clearCart();
        return newOrder;
      } else {
        const error = await response.json();
        throw new Error(error.message || 'Failed to place order');
      }
    } catch (err) {
      console.error('Order placement error:', err);
      alert('Failed to place order. Check server connection.');
      return null;
    }
  }

  // Check if current time is within bounds
  // Return format: { allowed: boolean, message: string }
  checkTimeBounds(isHostel) {
    const now = new Date();
    // Using current time instead of faking to test easily, you can modify logic below for testing
    const hours = now.getHours();
    const minutes = now.getMinutes();
    const currentTimeVal = hours + minutes / 60;

    if (isHostel) {
      // Hosteler: 11:00 AM to 8:00 PM (11 to 20)
      if (currentTimeVal >= 11 && currentTimeVal <= 20) {
        return { allowed: true, message: '' };
      }
      return { allowed: false, message: 'Hostel Canteens operate only between 11:00 AM and 8:00 PM.' };
    } else {
      // General/Non-Hosteler: 9:30 AM to 4:20 PM (9.5 to 16.33)
      if (currentTimeVal >= 9.5 && currentTimeVal <= 16.33) {
        return { allowed: true, message: '' };
      }
      return { allowed: false, message: 'General Canteens operate only between 9:30 AM and 4:20 PM.' };
    }
  }

  // Debug bypass for timing rules during testing
  debugTimeCheckBypass() {
    return { allowed: true, message: '' };
  }
}

const app = new AppState();

// UI Utilities
function requireAuth() {
  if (!app.user) {
    window.location.href = 'index.html';
  }
}

function renderNavbar() {
  const isHosteler = app.user && app.user.isHosteler;
  const navbar = `
    <nav class="navbar">
      <div class="container">
        <a href="dashboard.html" class="navbar-brand">
          🍍 <span>Aditya Foods</span>
        </a>
        <div class="navbar-nav">
          <a href="dashboard.html" class="nav-link">Main Canteens</a>
          ${isHosteler ? '<a href="hostel.html" class="nav-link">Hostel Canteens</a>' : ''}
          <a href="orders.html" class="nav-link">Orders</a>
          ${app.user && app.user.email === 'admin@aditya.edu' ? '<a href="admin.html" class="nav-link">Admin</a>' : ''}
          <a href="checkout.html" class="cart-icon">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="21" r="1"></circle><circle cx="20" cy="21" r="1"></circle><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path></svg>
            <span class="cart-badge">0</span>
          </a>
          <button onclick="app.logout()" class="btn btn-outline" style="padding: 6px 12px; font-size: 0.9rem;">Logout</button>
        </div>
      </div>
    </nav>
  `;
  document.body.insertAdjacentHTML('afterbegin', navbar);
  app.updateCartBadge();
}

// Global initialization
document.addEventListener('DOMContentLoaded', () => {
  // Common init code if needed
});
