const mongoose = require('mongoose');
require('dotenv').config({ path: '../.env' });
const Canteen = require('./models/canteenModel');
const Food = require('./models/foodModel');

async function checkFoods() {
    await mongoose.connect(process.env.MONGODB_URI);
    
    const c1 = await Canteen.findOne({name: 'Ball Canteen 1'});
    const c2 = await Canteen.findOne({name: 'Ball Canteen 2'});
    
    if (c1) {
        const c1Foods = await Food.find({canteenId: c1._id});
        console.log("Canteen 1 Foods:");
        console.log(c1Foods.map(f => ({name: f.name, price: f.price, stock: f.stock, avail: f.availability, img: f.image})));
    }
    
    if (c2) {
        const c2Foods = await Food.find({canteenId: c2._id});
        console.log("Canteen 2 Foods:");
        console.log(c2Foods.map(f => ({name: f.name, price: f.price, stock: f.stock, avail: f.availability, img: f.image})));
    }

    await mongoose.disconnect();
}
checkFoods();
