const mongoose = require('mongoose');
const fs = require('fs');
require('dotenv').config({ path: '../.env' });
const Canteen = require('./models/canteenModel');

async function run() {
    try {
        await mongoose.connect(process.env.MONGODB_URI);
        const canteens = await Canteen.find({});
        fs.writeFileSync('canteen_data.json', JSON.stringify(canteens.map(c => ({ id: c._id.toString(), name: c.name, email: c.email })), null, 2));
        console.log("Written to canteen_data.json");
    } catch (e) {
        console.error(e);
    } finally {
        await mongoose.disconnect();
    }
}
run();
