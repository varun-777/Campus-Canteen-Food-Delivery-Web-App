const mongoose = require('mongoose');
require('dotenv').config({ path: '../.env' });
const Canteen = require('./models/canteenModel');

async function checkBallCanteen1Food() {
    await mongoose.connect(process.env.MONGODB_URI);
    
    // Let's find "Ball Canteen 1" 
    const c1 = await Canteen.findOne({name: 'Ball Canteen 1'});
    console.log("Found Canteen 1:", c1 ? c1._id : "null");
    
    // Let's find all foods for this canteen
    const Food = require('./models/foodModel');
    const c1Foods = await Food.find({canteenId: c1._id});
    console.log("Total Food Items in Canteen 1:", c1Foods.length);
    
    const c2 = await Canteen.findOne({name: 'Ball Canteen 2'});
    const c2Foods = await Food.find({canteenId: c2._id});
    console.log("Total Food Items in Canteen 2:", c2Foods.length);

    await mongoose.disconnect();
}

checkBallCanteen1Food();
