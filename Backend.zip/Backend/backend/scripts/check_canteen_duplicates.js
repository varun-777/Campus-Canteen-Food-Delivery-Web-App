const mongoose = require('mongoose');
const Canteen = require('./models/canteenModel');
require('dotenv').config();

async function findDuplicateCanteens() {
    await mongoose.connect(process.env.MONGODB_URI);
    
    const canteens = await Canteen.find({});
    const nameMap = {};
    
    canteens.forEach(c => {
        if (!nameMap[c.name]) nameMap[c.name] = [];
        nameMap[c.name].push({ email: c.email, id: c._id });
    });

    console.log('--- Canteen Name Duplicates ---');
    for (let name in nameMap) {
        if (nameMap[name].length > 1) {
            console.log(`Duplicate Name: "${name}"`);
            nameMap[name].forEach(c => console.log(`  - ${c.email} | ID: ${c.id}`));
        } else {
             // console.log(`Unique: "${name}"`);
        }
    }

    await mongoose.disconnect();
}

findDuplicateCanteens();
