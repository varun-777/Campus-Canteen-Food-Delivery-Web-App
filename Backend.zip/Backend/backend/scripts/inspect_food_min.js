const mongoose = require('mongoose');
const Canteen = require('./models/canteenModel');
const Food = require('./models/foodModel');
require('dotenv').config();

async function inspectItems() {
    await mongoose.connect(process.env.MONGODB_URI);
    
    // Check Wada (2pcs)
    const rb1 = await Canteen.findOne({ name: 'Ramanujan Bhavan Canteen 1' });
    if (rb1) {
        const wada = await Food.findOne({ canteenId: rb1._id, name: 'Wada (2pcs)' });
        console.log('RB1_WADA:', JSON.stringify(wada));
        const allRB1 = await Food.find({ canteenId: rb1._id });
        console.log('RB1_ALL_NAMES:', allRB1.map(f => f.name).join(', '));
    }

    // Check Fresh Orange Juice
    const juices = await Canteen.findOne({ name: 'Juices Shop' });
    if (juices) {
        const juice = await Food.findOne({ canteenId: juices._id, name: 'Fresh Orange Juice' });
        console.log('JUICE_ORANGE:', JSON.stringify(juice));
        const allJuices = await Food.find({ canteenId: juices._id });
        console.log('JUICE_ALL_NAMES:', allJuices.map(f => f.name).join(', '));
    }

    await mongoose.disconnect();
}

inspectItems();
