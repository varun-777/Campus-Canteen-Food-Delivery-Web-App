const mongoose = require('mongoose');
const User = require('./models/User');
const Order = require('./models/Order');
const Canteen = require('./models/canteenModel');
const Food = require('./models/foodModel');
const fs = require('fs');
require('dotenv').config();

async function checkDB() {
    try {
        await mongoose.connect(process.env.MONGODB_URI);
        let output = '--- Connected to MongoDB ---\n';

        const users = await User.find({});
        output += `\nUsers in DB: ${users.length}\n`;
        users.forEach(u => {
            output += `- ${u.name} | ${u.email} | ID: ${u._id}\n`;
        });

        const canteens = await Canteen.find({});
        output += `\nCanteens in DB: ${canteens.length}\n`;
        canteens.forEach(c => {
            output += `- ${c.name} | ${c.email} | ID: ${c._id}\n`;
        });

        const foods = await Food.find({});
        output += `\nFoods in DB: ${foods.length}\n`;
        // No need to list all foods, just count is fine for now

        const orders = await Order.find({});
        output += `\nOrders in DB: ${orders.length}\n`;
        orders.forEach(o => {
            output += `- OrderId: ${o.orderId} | ID: ${o._id} | UserID: ${o.userId} | Total: ${o.total} | Date: ${o.date}\n`;
        });

        fs.writeFileSync('db_diagnostic.txt', output);
        console.log('Diagnostic info written to db_diagnostic.txt');
        await mongoose.disconnect();
    } catch (err) {
        console.error('Error:', err);
    }
}

checkDB();

