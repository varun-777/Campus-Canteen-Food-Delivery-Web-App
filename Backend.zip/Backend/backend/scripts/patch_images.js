const fs = require('fs');
const https = require('https');

try {
  let content = fs.readFileSync('common.js', 'utf8');
  const urls = [];
  const regex = /image:\s*['"](http[^'"]+)['"]/g;
  let m;
  while ((m = regex.exec(content)) !== null) {
      urls.push(m[1]);
  }
  const uniqueUrls = [...new Set(urls)];

  (async () => {
    let replacedCount = 0;
    for (const url of uniqueUrls) {
      await new Promise(resolve => {
        https.get(url, res => {
          if (res.statusCode >= 400 || res.statusCode === 301) {
             console.log("Broken:", res.statusCode, url);
             content = content.split(url).join('assets/samosa.png');
             replacedCount++;
          }
          resolve();
        }).on('error', (e) => {
             console.log("Error:", e.message, url);
             content = content.split(url).join('assets/samosa.png');
             replacedCount++;
             resolve();
        });
      });
    }
    fs.writeFileSync('common.js', content);
    console.log("Replaced", replacedCount, "broken links.");
  })();
} catch (e) {
  console.error("Script error:", e);
}
