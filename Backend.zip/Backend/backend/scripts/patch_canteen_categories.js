const mongoose = require('mongoose');
const Canteen = require('./models/canteenModel');

const boys = ['Krishna Canteen', 'Aparna Canteen'];
const girls = ['Rose Canteen', 'Lily Canteen', 'Jasmine Canteen'];

async function patch() {
    try {
        await mongoose.connect('mongodb://127.0.0.1:27017/aditya_foods');
        console.log('Connected to DB');

        await Canteen.updateMany({ name: { $in: boys } }, { $set: { category: 'hostelBoys' } });
        console.log('Updated Boys Hostels');
        
        await Canteen.updateMany({ name: { $in: girls } }, { $set: { category: 'hostelGirls' } });
        console.log('Updated Girls Hostels');
        
        // Also ensure others remain general
        const allKnown = [...boys, ...girls];
        await Canteen.updateMany({ name: { $nin: allKnown }, category: { $exists: false } }, { $set: { category: 'general' } });
        console.log('Ensured other missing categories default to general.');
        
        console.log('Done!');
        mongoose.disconnect();
    } catch(err) {
        console.error(err);
        process.exit(1);
    }
}

patch();
