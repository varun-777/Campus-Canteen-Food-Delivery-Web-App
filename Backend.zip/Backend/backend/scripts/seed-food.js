const mongoose = require('mongoose');
const Canteen = require('./models/canteenModel');
const Food = require('./models/foodModel');
require('dotenv').config();

const genericMenu = [
    { id: 'm1', name: 'Chicken Biryani', price: 180, image: 'assets/chick.jpg', desc: 'Aromatic basmati rice with spicy chicken', diet: 'nonveg' },
    { id: 'm2', name: 'Veg Fried Rice', price: 100, image: 'assets/vegfriedrice.jpg', desc: 'Classic Chinese style fried rice with veggies', diet: 'veg' },
    { id: 'm3', name: 'Masala Dosa', price: 60, image: 'assets/masaladosa.jpg', desc: 'Crispy rice crepe with potato masala', diet: 'veg' },
    { id: 'm4', name: 'Paneer Butter Masala', price: 150, image: 'https://images.unsplash.com/photo-1631452180519-c014fe946bc7?q=80&w=600&auto=format&fit=crop', desc: 'Rich and creamy curry with soft cottage cheese', diet: 'veg' },
    { id: 'm5', name: 'Veg Noodles', price: 90, image: 'assets/vegnoodles.jpg', desc: 'Hakka style stir-fried noodles', diet: 'veg' },
    { id: 'm6', name: 'Chicken Manchurian', price: 130, image: 'assets/chickmanchuria.jpg', desc: 'Crispy chicken chunks in spicy soy sauce', diet: 'nonveg' },
    { id: 'm7', name: 'Fresh Watermelon Juice', price: 50, image: 'assets/watermelon-juice.jpg', desc: 'Refreshing juice without added sugar', diet: 'veg' },
    { id: 'm8', name: 'Egg Puff', price: 25, image: 'assets/egg_puff.png', desc: 'Flaky pastry with spicy egg filling', diet: 'eggetarian' }
];

const ballMenu = [
    { id: 'bt1', name: 'Chicken Tikka', price: 220, image: 'assets/chicken_tikka.jpg', diet: 'nonveg' },
    { id: 'br1', name: 'Chicken Roll', price: 120, image: 'assets/chicken_roll.png', desc: 'Soft paratha wrapped with spicy chicken', diet: 'nonveg' },
    { id: 'bp1', name: 'Cashew Chicken Pakoda', price: 150, image: 'assets/cashewchickpakodi.jpg', desc: 'Crunchy pakoda with cashews and chicken', diet: 'nonveg' },
    { id: 'bo1', name: 'Omelette', price: 40, image: 'assets/omelette.png', desc: 'Fluffy double egg omelette', diet: 'eggetarian' },
    { id: 'bo2', name: 'Bread Omelette', price: 60, image: 'assets/breadomlette.jpg', desc: 'Classic street style bread omelette', diet: 'eggetarian' },
    { id: 'ep1', name: 'Egg Puffs', price: 25, image: 'assets/egg_puff.png', desc: 'Crispy pastry with egg filling', diet: 'eggetarian' },
    { id: 'cp1', name: 'Curry Puffs', price: 20, image: 'assets/currypuffs.jpg', desc: 'Spiced potato and peas filling', diet: 'veg' },
    { id: 'vr1', name: 'Veg Roll', price: 80, image: 'assets/vegroll.jpg', desc: 'Fresh veggies wrapped in a roll', diet: 'veg' },
    { id: 's1', name: 'Samosa', price: 15, image: 'assets/samosa.png', desc: 'Classic crispy potato samosa', diet: 'veg' },
    { id: 'pt1', name: 'Paneer Tikka', price: 180, image: 'assets/paneertikka.jpg', desc: 'Marinated paneer cubes grilled to perfection', diet: 'veg' }
];

const fruitMenu = [
    { id: 'f1', name: 'Watermelon Bowl', price: 60, image: 'assets/watermelon_bowl.jpg', desc: 'Freshly cut sweet watermelon' },
    { id: 'f2', name: 'Papaya Bowl', price: 50, image: 'assets/papayabowl.jpg', desc: 'Ripe and healthy papaya slices' },
    { id: 'f3', name: 'Banana (Dozen)', price: 60, image: 'https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?q=80&w=600&auto=format&fit=crop', desc: 'Fresh yellow bananas' },
    { id: 'f4', name: 'Pineapple Slices', price: 70, image: 'assets/pineappleslice.jpg', desc: 'Sweet and tangy pineapple' },
    { id: 'f5', name: 'Coconut Water', price: 40, image: 'assets/cocowater.jpg', desc: 'Natural refreshing tender coconut' },
    { id: 'f6', name: 'Grapes Bowl', price: 80, image: 'assets/grapesbowl.jpg', desc: 'Sweet seedless green grapes' },
    { id: 'f7', name: 'Mixed Fruit Salad', price: 100, image: 'assets/mixedsalad.jpg', desc: 'Assorted seasonal fruits' }
];

const juiceMenu = [
    { id: 'j1', name: 'Fresh Orange Juice', price: 70, image: 'assets/Orange.jpg', desc: 'Pure orange juice with pulp' },
    { id: 'j2', name: 'Watermelon Juice', price: 50, image: 'assets/watermelon-juice.jpg', desc: 'Cooling watermelon extract' },
    { id: 'j3', name: 'Mango Milkshake', price: 90, image: 'assets/mangothickshake.jpg', desc: 'Thick and creamy mango shake' },
    { id: 'j4', name: 'Chocolate Milkshake', price: 100, image: 'assets/chocolateshake.jpg', desc: 'Rich chocolatey goodness' },
    { id: 'j5', name: 'Strawberry Shake', price: 90, image: 'assets/strawberryshake.jpg', desc: 'Fresh strawberry blended with milk' },
    { id: 'j6', name: 'Pineapple Juice', price: 60, image: 'assets/pineapplejuice.jpg', desc: 'Freshly squeezed pineapple' },
    { id: 'j7', name: 'Vanilla Milkshake', price: 80, image: 'assets/vanillashake.jpg', desc: 'Classic smooth vanilla shake' },
    { id: 'j8', name: 'Badam Milk', price: 50, image: 'assets/badammilk.jpg', desc: 'Traditional almond milk with saffron' }
];

const bakeryMenu = [
    { id: 'bk1', name: 'Assorted Chocolates', price: 50, image: 'https://images.unsplash.com/photo-1549007994-cb92caebd54b?q=80&w=600&auto=format&fit=crop', desc: 'Handcrafted chocolate bars' },
    { id: 'bk2', name: 'Butter Biscuits (Pkt)', price: 40, image: 'https://images.unsplash.com/photo-1558961363-fa8fdf82db35?q=80&w=600&auto=format&fit=crop', desc: 'Crispy and buttery cookies' },
    { id: 'bk3', name: 'Chocolate Cake', price: 70, image: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?q=80&w=600&auto=format&fit=crop', desc: 'Rich layer of chocolate cream' },
    { id: 'bk4', name: 'Red Velvet Pastry', price: 85, image: 'https://images.unsplash.com/photo-1616541823729-00fe0aacd32c?q=80&w=600&auto=format&fit=crop', desc: 'Classic red velvet flavor' },
    { id: 'bk5', name: 'Chicken Puff', price: 35, image: 'assets/chicken_puff.jpg', desc: 'Spicy chicken filling in flaky crust' },
    { id: 'bk6', name: 'Curry Puff', price: 25, image: 'assets/currypuffs.jpg', desc: 'Mixed veg curry filling' },
    { id: 'bk7', name: 'Onion Samosa (3pc)', price: 30, image: 'assets/samosa.png', desc: 'Mini crunchy onion samosas' }
];

const hostelMenu = [
    { id: 'h1', name: 'Veg Thali', price: 80, image: 'https://images.unsplash.com/photo-1606491956689-2ea866880c84?q=80&w=600&auto=format&fit=crop', desc: 'Rice, Dal, 2 Veg Curries, Sambar, Curd' },
    { id: 'h2', name: 'Chicken Thali', price: 120, image: 'https://images.unsplash.com/photo-1606491956689-2ea866880c84?q=80&w=600&auto=format&fit=crop', desc: 'Rice, Dal, Chicken Curry, Fry, Curd' },
    { id: 'h3', name: 'Maggi', price: 40, image: 'assets/maggi.jpg', desc: 'Classic vegetable masala maggi' },
    { id: 'h4', name: 'Tea', price: 15, image: 'assets/Teaa.jpg', desc: 'Hot ginger tea' },
    { id: 'h5', name: 'Coffee', price: 20, image: 'assets/coffeee.jpg', desc: 'Strong roasted coffee' },
    { id: 'h6', name: 'Bread Omelette', price: 60, image: 'assets/omelette.png', desc: 'Classic hostel night snack' }
];

const pencilMenu = [
    { id: 'pc_cfr', name: 'Chicken Fried Rice', price: 120, image: 'https://images.unsplash.com/photo-1603133872878-684f208fb84b?q=80&w=600&auto=format&fit=crop', desc: 'Wok-tossed rice with tender chicken and veggies' },
    { id: 'pc_vfr', name: 'Veg Fried Rice', price: 90, image: 'assets/vegfriedrice.jpg', desc: 'Classic vegetable fried rice with fresh greens' },
    { id: 'pc_efr', name: 'Egg Fried Rice', price: 100, image: 'assets/eggfryrrice.jpg', desc: 'Aromatic fried rice with scrambled eggs' },
    { id: 'pc_cn', name: 'Chicken Noodles', price: 120, image: 'assets/chickennoodles.jpg', desc: 'Spicy hakka noodles with chicken chunks' },
    { id: 'pc_vn', name: 'Veg Noodles', price: 90, image: 'assets/vegnoodles.jpg', desc: 'Stir-fried noodles with crisp vegetables' },
    { id: 'pc_en', name: 'Egg Noodles', price: 100, image: 'assets/noodles.jpg', desc: 'Delicious noodles tossed with eggs' },
    { id: 'pc_cr', name: 'Chicken Roll', price: 80, image: 'assets/chicken_roll.png', desc: 'Flavorful chicken filling wrapped in a soft roll' },
    { id: 'pc_vr', name: 'Veg Roll', price: 60, image: 'assets/vegroll.jpg', desc: 'Fresh vegetable mix wrapped in a crispy roll' }
];

const ramanujanMenu = [
    { id: 'r1', name: 'Idly (4pcs)', price: 40, image: 'assets/idly.jpg', desc: 'Steamed rice cakes with chutney and sambar' },
    { id: 'r2', name: 'Wada (2pcs)', price: 40, image: 'assets/Wadaaa.jpg', desc: 'Crispy lentil donuts' },
    { id: 'r3', name: 'Masala Dosa', price: 60, image: 'assets/masaladosa.jpg', desc: 'Crispy rice crepe with potato masala' },
    { id: 'r4', name: 'Mysore Bajji', price: 50, image: 'assets/mysorebajji.jpg', desc: 'Fluffy fried dough balls' }
];

const noodlesMenu = [
    { id: 'n1', name: 'Veg Noodles', price: 90, image: 'assets/vegnoodles.jpg', desc: 'Classic stir-fried veg noodles' },
    { id: 'n2', name: 'Chicken Noodles', price: 120, image: 'assets/chickennoodles.jpg', desc: 'Spicy noodles with chicken chunks' },
    { id: 'n3', name: 'Veg Manchurian', price: 100, image: 'assets/vegmanchuria.jpg', desc: 'Fried veg balls in spicy gravy' },
    { id: 'n4', name: 'Chicken Manchurian', price: 140, image: 'assets/chickmanchuria.jpg', desc: 'Crispy chicken in manchurian sauce' }
];

const fastfoodMenu = [
    { id: 'ff1', name: 'Veg Burger', price: 80, image: 'assets/vegburger.jpg', desc: 'Crispy veg patty with cheese' },
    { id: 'ff2', name: 'Chicken Burger', price: 120, image: 'assets/chickburger.jpg', desc: 'Juicy chicken grill patty' },
    { id: 'ff3', name: 'Cheese Pizza', price: 150, image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?q=80&w=600&auto=format&fit=crop', desc: 'Loaded with mozzarella cheese' },
    { id: 'ff4', name: 'French Fries', price: 60, image: 'assets/frenchfries.jpg', desc: 'Crispy salted potato fries' }
];

const canteenMenus = {
    'b1': ballMenu,
    'b2': ballMenu,
    'p1': pencilMenu,
    'p2': pencilMenu,
    'fruits': fruitMenu,
    'juices': juiceMenu,
    'bakery': bakeryMenu,
    'noodles': noodlesMenu,
    'fastfood': fastfoodMenu,
    'rb1': ramanujanMenu,
    'rb2': noodlesMenu,
    'rk': genericMenu,
    'krishna': hostelMenu,
    'aparna': hostelMenu,
    'g1': hostelMenu,
    'g2': hostelMenu,
    'g3': hostelMenu,
    'eatplay': ballMenu
};

const canteenNameMapping = {
    'b1': 'Ball Canteen 1', 'b2': 'Ball Canteen 2', 'p1': 'Pencil Canteen 1', 'p2': 'Pencil Canteen 2',
    'bakery': 'Bakery', 'eatplay': 'Eat and Play', 'rb1': 'Ramanujan Bhavan Canteen 1', 'rb2': 'Ramanujan Bhavan Canteen 2',
    'rk': 'Rama Krishna Canteen', 'noodles': 'Noodles Shop', 'fastfood': 'Fastfood Shop', 'juices': 'Juices Shop',
    'fruits': 'Fruits Shop', 'krishna': 'Krishna Canteen', 'aparna': 'Aparna Canteen', 'g1': 'Rose Canteen',
    'g2': 'Lily Canteen', 'g3': 'Jasmine Canteen'
};

async function seedFood() {
    await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/food_delivery');
    console.log('Connected to DB');

    for (const [shortId, menuItems] of Object.entries(canteenMenus)) {
        const canteenFullName = canteenNameMapping[shortId];
        if (!canteenFullName) continue;

        const canteens = await Canteen.find({ name: canteenFullName });
        if (canteens.length === 0) {
            console.log(`Canteen not found in DB: ${canteenFullName}`);
            continue;
        }

        for (const canteen of canteens) {
            console.log(`Processing ${canteenFullName} (${canteen.email})...`);
            for (const item of menuItems) {
                try {
                    const existing = await Food.findOne({ canteenId: canteen._id, name: item.name });
                    if (existing) {
                        await Food.updateOne(
                            { _id: existing._id },
                            {
                                $set: {
                                    image: item.image,
                                    price: item.price,
                                    category: item.diet ? item.diet.charAt(0).toUpperCase() + item.diet.slice(1) : (existing.category || 'General')
                                }
                            }
                        );
                        console.log(`Updated ${item.name} in ${canteenFullName}`);
                    } else {
                        await Food.create({
                            name: item.name,
                            price: item.price,
                            image: item.image,
                            category: item.diet ? item.diet.charAt(0).toUpperCase() + item.diet.slice(1) : 'General',
                            availability: true,
                            canteenId: canteen._id
                        });
                        console.log(`Added ${item.name} to ${canteenFullName}`);
                    }
                } catch (err) {
                    console.error(`Error processing ${item.name}:`, err.message);
                }
            }
        }
    }

    console.log('Food Seeding completed!');
    mongoose.disconnect();
}

seedFood();
