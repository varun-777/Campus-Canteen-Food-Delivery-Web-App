const mongoose = require('mongoose');
const Canteen = require('./models/canteenModel');
require('dotenv').config();

const canteenNames = [
    'Ball Canteen 1', 'Ball Canteen 2', 'Pencil Canteen 1', 'Pencil Canteen 2',
    'Bakery', 'Eat and Play', 'Ramanujan Bhavan Canteen 1', 'Ramanujan Bhavan Canteen 2',
    'Rama Krishna Canteen', 'Noodles Shop', 'Fastfood Shop', 'Juices Shop', 'Fruits Shop',
    'Krishna Canteen', 'Aparna Canteen', 'Rose Canteen', 'Lily Canteen', 'Jasmine Canteen'
];

async function seedAll() {
    await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/food_delivery');
    console.log('Connected to DB');

    for (let name of canteenNames) {
        const formattedEmailName = name.toLowerCase().replace(/\s+/g, '');
        const email = `${formattedEmailName}@gmail.com`;
        const password = '123456';

        try {
            let existing = await Canteen.findOne({ email });
            if (existing) {
                console.log(`Canteen already exists: ${name} (${email})`);
            } else {
                await Canteen.create({ name, email, password });
                console.log(`Successfully created: ${name} (${email})`);
            }
        } catch (err) {
            console.error(`Error creating ${name}:`, err.message);
        }
    }
    
    mongoose.disconnect();
}

seedAll();
