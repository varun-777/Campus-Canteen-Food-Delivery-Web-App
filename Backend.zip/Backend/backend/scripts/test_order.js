const http = require('http');

const data = JSON.stringify({
  orderId: "ORD1234",
  email: "admin@aditya.edu", // this user must exist. I'll use a random email and see if it fails on user not found or something else.
  items: [{"id":"m1", "name":"Chicken Biryani", "price":180, "qty":1, "canteenId":"b1"}],
  subtotal: 180,
  deliveryFee: 20,
  total: 200,
  deliveryDetails: {location:"Block A", roomNo:"101", phone:"1234567890", method:"Cash", notes:""}
});

const req = http.request({
  hostname: 'localhost',
  port: 5000,
  path: '/api/orders',
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Content-Length': data.length
  }
}, res => {
  let body = '';
  res.on('data', d => body += d);
  res.on('end', () => console.log('Response:',res.statusCode, body));
});

req.on('error', error => {
  console.error(error);
});

req.write(data);
req.end();
