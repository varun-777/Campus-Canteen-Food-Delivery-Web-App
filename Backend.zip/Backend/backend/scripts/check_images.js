const fs = require('fs');
const https = require('https');

const content = fs.readFileSync('common.js', 'utf8');
const urls = [];
let match;
const regex = /image:\s*['"]([^'"]+)['"]/g;

while ((match = regex.exec(content)) !== null) {
  urls.push(match[1]);
}

const uniqueUrls = [...new Set(urls)].filter(u => u.startsWith('http'));

async function checkUrl(url) {
  return new Promise((resolve) => {
    https.get(url, (res) => {
      resolve({url, status: res.statusCode});
    }).on('error', (e) => {
      resolve({url, status: 'Error: ' + e.message});
    });
  });
}

(async () => {
  for (const url of uniqueUrls) {
    const res = await checkUrl(url);
    if (res.status >= 400) {
       console.log('BROKEN:', res.url);
    }
  }
  console.log('DONE CHECKING');
})();
