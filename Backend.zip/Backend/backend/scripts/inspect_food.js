const mongoose = require('mongoose');
const Canteen = require('./models/canteenModel');
const Food = require('./models/foodModel');
require('dotenv').config();

async function inspectItems() {
    await mongoose.connect(process.env.MONGODB_URI);
    
    const targets = [
        { name: 'Ramanujan Bhavan Canteen 1', items: ['Wada (2pcs)'] },
        { name: 'Juices Shop', items: ['Fresh Orange Juice'] }
    ];

    for (let target of targets) {
        console.log(`\n--- Inspecting ${target.name} ---`);
        const canteen = await Canteen.findOne({ name: target.name });
        if (!canteen) {
            console.log('Canteen NOT FOUND');
            continue;
        }
        
        const foods = await Food.find({ canteenId: canteen._id });
        console.log(`Found ${foods.length} items in this canteen:`);
        foods.forEach(f => {
            const isTarget = target.items.includes(f.name);
            console.log(`${isTarget ? '>> ' : '   '} ${f.name} | Image: ${f.image} | ID: ${f._id}`);
        });
    }

    await mongoose.disconnect();
}

inspectItems();
