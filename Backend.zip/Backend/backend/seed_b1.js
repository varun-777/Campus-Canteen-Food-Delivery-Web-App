const mongoose = require('mongoose');
require('dotenv').config({ path: '../.env' });
const Canteen = require('./models/canteenModel');
const Food = require('./models/foodModel');

const ballMenu = [
    { id: 'b_biryani', name: 'Chicken Biryani', price: 180, image: 'assets/chick.jpg', desc: 'Signature aromatic biryani', diet: 'nonveg' },
    { id: 'bt1', name: 'Chicken Tikka', price: 220, image: 'https://images.unsplash.com/photo-1565557623262-b51c2513a641?q=80&w=600&auto=format&fit=crop', desc: 'Char-grilled marinated chicken chunks', diet: 'nonveg' },
    { id: 'br1', name: 'Chicken Roll', price: 120, image: 'assets/chicken_roll.png', desc: 'Soft paratha wrapped with spicy chicken', diet: 'nonveg' },
    { id: 'bp1', name: 'Cashew Chicken Pakoda', price: 150, image: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?q=80&w=600&auto=format&fit=crop', desc: 'Crunchy pakoda with cashews and chicken', diet: 'nonveg' },
    { id: 'bo1', name: 'Omelette', price: 40, image: 'assets/omelette.png', desc: 'Fluffy double egg omelette', diet: 'eggetarian' },
    { id: 'bo2', name: 'Bread Omelette', price: 60, image: 'assets/omelette.png', desc: 'Classic street style bread omelette', diet: 'eggetarian' },
    { id: 'ep1', name: 'Egg Puffs', price: 25, image: 'assets/egg_puff.png', desc: 'Crispy pastry with egg filling', diet: 'eggetarian' },
    { id: 'cp1', name: 'Curry Puffs', price: 20, image: 'https://images.unsplash.com/photo-1626074353765-517a681e40be?q=80&w=600&auto=format&fit=crop', desc: 'Spiced potato and peas filling', diet: 'veg' },
    { id: 'vr1', name: 'Veg Roll', price: 80, image: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?q=80&w=600&auto=format&fit=crop', desc: 'Fresh veggies wrapped in a roll', diet: 'veg' },
    { id: 's1', name: 'Samosa', price: 15, image: 'assets/samosa.png', desc: 'Classic crispy potato samosa', diet: 'veg' },
    { id: 'pt1', name: 'Paneer Tikka', price: 180, image: 'assets/samosa.png', desc: 'Marinated paneer cubes grilled to perfection', diet: 'veg' }
];

async function seedBallCanteen1() {
    try {
        await mongoose.connect(process.env.MONGODB_URI);
        const canteen = await Canteen.findOne({ name: 'Ball Canteen 1' });
        
        if (!canteen) {
            console.log("Canteen 1 not found");
            return;
        }

        for (const item of ballMenu) {
            const existing = await Food.findOne({ canteenId: canteen._id, name: item.name });
            if (!existing) {
                await Food.create({
                    name: item.name,
                    price: item.price,
                    image: item.image,
                    category: item.diet ? item.diet.charAt(0).toUpperCase() + item.diet.slice(1) : 'General',
                    availability: true,
                    stock: -1, // Unlimited stock
                    canteenId: canteen._id
                });
                console.log(`Added ${item.name}`);
            } else {
                console.log(`${item.name} already exists`);
            }
        }
        console.log("Finished seeding Ball Canteen 1");
    } catch(e) {
        console.error(e);
    } finally {
        await mongoose.disconnect();
    }
}

seedBallCanteen1();
