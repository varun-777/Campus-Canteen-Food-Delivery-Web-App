const mongoose = require('mongoose');
require('dotenv').config({ path: '../.env' });
const Order = require('./models/Order');

async function testOrders() {
    try {
        await mongoose.connect(process.env.MONGODB_URI);
        
        const ballC1Id = "69c686b4f804ec43c5c67b8e";
        const queryConditions = [
            { 'items.canteenId': ballC1Id }
        ];

        if (mongoose.Types.ObjectId.isValid(ballC1Id)) {
            queryConditions.push({ canteenId: ballC1Id });
        }
        
        // Simulating the shortId mapped
        queryConditions.push({ 'items.canteenId': 'b1' });
        
        console.log("Query Conditions:", JSON.stringify(queryConditions, null, 2));
        const results = await Order.find({ $or: queryConditions });
        console.log("Results for Ball Canteen 1:", results.length);
    } catch(e) {
        console.error("Error:", e);
    } finally {
        await mongoose.disconnect();
    }
}
testOrders();
