const mongoose = require('mongoose');

const orderSchema = new mongoose.Schema({
    orderId: { type: String, required: true, unique: true },
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    canteenId: { type: mongoose.Schema.Types.ObjectId, ref: 'Canteen', required: false },
    items: [{
        id: String,
        name: String,
        price: Number,
        qty: Number,
        canteenId: String
    }],
    subtotal: Number,
    deliveryFee: Number,
    total: Number,
    status: { type: String, default: 'Preparing' },
    deliveryDetails: {
        location: String,
        roomNo: String,
        phone: String,
        method: String,
        notes: String
    },
    date: { type: Date, default: Date.now },
    rating: { type: Number, default: 0 },
    review: { type: String, default: '' }
});

module.exports = mongoose.model('Order', orderSchema);
