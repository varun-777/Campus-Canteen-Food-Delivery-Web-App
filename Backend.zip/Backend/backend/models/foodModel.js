const mongoose = require('mongoose');

const foodSchema = new mongoose.Schema({
    name: { type: String, required: true },
    price: { type: Number, required: true },
    category: { type: String, required: true },
    image: { type: String, required: true },
    availability: { type: Boolean, default: true },
    stock: { type: Number, default: -1 }, // -1 means unlimited
    canteenId: { type: mongoose.Schema.Types.ObjectId, ref: 'Canteen', required: true }
});

module.exports = mongoose.model('Food', foodSchema);
